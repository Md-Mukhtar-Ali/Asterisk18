<?php
require_once 'vendor/autoload.php';

use PAMI\Client\Impl\ClientImpl as PamiClient;
use PAMI\Message\Event\EventMessage;
use PAMI\Message\Action\LoginAction;
use PAMI\Message\Action\LogoffAction;

// PAMI Client configuration
$options = array(
    'host' => '127.0.0.1',
    'scheme' => 'tcp://',
    'port' => 5038,
    'username' => 'phpuser', // AMI user
    'secret' => 'phpami_password', // AMI password
    'connect_timeout' => 10000,
    'read_timeout' => 10000
);

$pamiClient = new PamiClient($options);

// Open the connection to AMI
$pamiClient->open();

// Login to AMI
$pamiClient->send(new LoginAction());

// Loop to listen for events
while (true) {
    // Wait for events
    $response = $pamiClient->process();

    // Check for DeviceStateChange or EndpointStatus events
    if ($response instanceof EventMessage) {
        $eventName = $response->getKey('Event');

        if ($eventName == 'DeviceStateChange' || $eventName == 'EndpointList') {
            $device = $response->getKey('Device');
            $state = $response->getKey('State');
            
            // Example: Save device state to the database
            saveDeviceStatusToDatabase($device, $state);
        }
    }

    sleep(1); // Avoid busy-waiting
}

// Logoff and close the connection
$pamiClient->send(new LogoffAction());
$pamiClient->close();

/**
 * Function to save device status to database
 */
function saveDeviceStatusToDatabase($device, $state)
{
    // Database connection
    $mysqli = new mysqli("localhost", "username", "password", "asterisk");

    if ($mysqli->connect_error) {
        die("Connection failed: " . $mysqli->connect_error);
    }

    $stmt = $mysqli->prepare("INSERT INTO device_status (device, status) VALUES (?, ?) ON DUPLICATE KEY UPDATE status=?");
    $stmt->bind_param("sss", $device, $state, $state);

    $stmt->execute();
    $stmt->close();
    $mysqli->close();
}
