#!/usr/bin/env /bin/php

<?php
require('phpagi.php');
//require('include/phpagi.php');
error_reporting(E_ALL);

//$db_ip = "127.0.0.1";
$db_ip = "localhost";
$db_user = "vitel_user";
$db_port = "3306";
$db_pass = "vitel_pbx123";

// Create MySQL connection
$mysqli = new mysqli($db_ip, $db_user, $db_pass, "asterisk");
if ($mysqli->connect_errno) {
    fwrite($stderr, "Failed to connect to MySQL: " . $mysqli->connect_error . "\n");
    exit(1);
}
# create new Agi
$AGI = new AGI();

if (!$AGI) {
        // something went wrong
$AGI->verbose("something went wrong");
        exit(1);
}
$AGI->verbose("MySQL connection Up");
$AGI->verbose("script starting up");

    // set parameters
    $Tenant = $argv[1];
    $Exten  = $argv[2];
$AGI->verbose("call for \"$Tenant$Exten\"");

//  Check Call Forward Status and Fetch Forward Number data from a MySQL table

$query = "SELECT enable_callforward,callfwd_num FROM ext_options where id='$Tenant$Exten'";
if ($result = $mysqli -> query($query)) {
  // Get field information for all fields
    $AGI->verbose($result);
    
    while ($fieldinfo = $result -> fetch_assoc()) {
    $AGI->verbose($result);
    $CF_status=$fieldinfo["enable_callforward"];
    $AGI->verbose("Call Forward status is $CF_status");
    $CF_Num=$fieldinfo["callfwd_num"];
    $AGI->verbose("Calls of $Exten being forwarded to $CF_Num");
  }
  $result->free_result();
}

$mysqli->close();    
    # set return variable
$AGI->verbose("Call Forward Number outside while loop is $CF_Num");
    $AGI->set_variable("CFNumber", $CF_Num);
    $AGI->set_variable("CF_Status", $CF_status);
?>
