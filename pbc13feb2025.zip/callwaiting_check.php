#!/usr/bin/env /bin/php

<?php
require('phpagi.php');
//require('include/phpagi.php');
error_reporting(E_ALL);

//$db_ip = "127.0.0.1";
$db_ip = "localhost";
$db_user = "vitel_user";
$db_port = "3306";
$db_pass = "vitel_pbx123";

// Create MySQL connection
$mysqli = new mysqli($db_ip, $db_user, $db_pass, "asterisk");
if ($mysqli->connect_errno) {
    fwrite($stderr, "Failed to connect to MySQL: " . $mysqli->connect_error . "\n");
    exit(1);
}
# create new Agi
$AGI = new AGI();

if (!$AGI) {
        exit(1);
}
$AGI->verbose("MySQL connection Up");
$AGI->verbose("script starting up");

    // set parameters
    $Tenant = $argv[1];
    $Exten  = $argv[2];
$AGI->verbose("call for \"$Tenant$Exten\"");

//  Check Call Forward Status and Fetch Forward Number data from a MySQL table

$query = "SELECT enable_callwaiting FROM ext_options where id='$Tenant$Exten'";
if ($result = $mysqli -> query($query)) {
  // Get field information for all fields
    $AGI->verbose($result);
    
    while ($fieldinfo = $result -> fetch_assoc()) {
    $AGI->verbose($result);
    $CW_status=$fieldinfo["enable_callwaiting"];
    $AGI->verbose("Call Waiting status is $CW_status");
  }
  $result->free_result();
}

$mysqli->close();    
    # set return variable
$AGI->verbose("Call Waiting Status outside while loop is $CW_status");
    $AGI->set_variable("CW_Status", $CW_status);
?>
