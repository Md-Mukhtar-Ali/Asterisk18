#!/usr/bin/env /bin/php
<?php
require('phpagi.php');
require('modules.php');
error_reporting(E_ALL);

$script_name = 'directory.php';
//$db_ip = "127.0.0.1";
$db_ip = "localhost";
$db_user = "vitel_user";
$db_port = "3306";
$db_pass = "vitel_pbx123";

// DECLARING LOCAL VARIABLES
$moh_class='default';


// Create MySQL connection
$mysqli = new mysqli($db_ip, $db_user, $db_pass, "asterisk");
if ($mysqli->connect_errno) {
    fwrite($stderr, "Failed to connect to MySQL: " . $mysqli->connect_error . "\n");
    exit(1);
}
# create new Agi
$AGI = new AGI();

if (!$AGI) {
        // something went wrong
        exit(1);
}
$AGI->verbose("MySQL connection Up");
$AGI->verbose("script $script_name starting up");

    // set parameters
    $directory_id     	= 	$argv[1];
    $customer_id    	= 	$argv[2];

$AGI->verbose("DIRECTORY APPLICATION - SEARCHING THROUGH $directory_id AND CUSTOMER $customer_id");


$query = "SELECT *  FROM directory where dir_id='$directory_id' and cust_id='$customer_id'";
$AGI->verbose($query);
$result = $mysqli->query($query);
if ($result->num_rows == 0) 
  {
        $AGI->verbose("NO DATA FOUND IN DB FOR THE GIVEN DIRECTORY ID");
        $AGI->exec('Gosub', 'terminate-call,s,1');
  }else
  {
	$AGI->verbose("DATA FOUND"); 

	$row = $result->fetch_assoc();

	$prompt_id	=	$row["prompt_id"];
	$max_inv_attempts	=	$row["invalid_loops"];
	$repeat_audio	=	$row["repeat_recording"];
	$final_audio	=	$row["invalid_final_recording"];
	$post_dest	=	$row["invalid_destination"];
	$post_dest_value=	$row["invalid_dest_value"];

  }
  $result->free_result();
// FUNCTION GET AUDIO LOC - START
//class ASTERISK_MODULES
  //{
/*
function get_audio_location($prompt_id, $mysqli, $AGI){
//      GETTING AUDIO PROMPT DETAILS - START
	$AGI->verbose("GETTING PROMPT ID IN FUNCTION $prompt_id");
        $audio_query = "SELECT File_Location  FROM pss_audio_files where File_id='$prompt_id'";
        $audio_result = $mysqli->query($audio_query);
        if ($audio_result->num_rows > 0)
        {
        $prompt_row = $audio_result->fetch_assoc();
        $aud_file_loc           =       $prompt_row["File_Location"];
	return($aud_file_loc);
        }else{
        	$AGI->verbose("PROMPT FILE LOCATION NOT FOUND");
		return("INVALID");
        }
//      GETTING AUDIO PROMPT DETAILS - END
} //FUNCTION GET AUDIO LOC - END
*/
	//$AM = new ASTERISK_MODULES();
	$AGI->verbose("GETTING AUDIO PROMPT LOCATION FOR $prompt_id");
	$aud_file_loc  = get_audio_location($prompt_id, $mysqli, $AGI);
        $AGI->verbose("AUDIO PROMPT IS $aud_file_loc");	

	$AGI->verbose("=====================================");
	$AGI->verbose("INITIAL PROMPT TO BE PLAYED IS $prompt_id");
	$AGI->verbose("INVALID ATTEMPTS IS $max_inv_attempts");
	$AGI->verbose("REPEAT RECORDING IS $repeat_audio");
	$AGI->verbose("INVALID FINAL AUDIO IS $final_audio");
	$AGI->verbose("FINAL DESTINATION IS $post_dest");
	$AGI->verbose("DESTINATION VALUE IS $post_dest_value");
	$AGI->verbose("=====================================");
	
$digitToLetter = array(
    '2' => 'ABC',
    '3' => 'DEF',
    '4' => 'GHI',
    '5' => 'JKL',
    '6' => 'MNO',
    '7' => 'PQRS',
    '8' => 'TUV',
    '9' => 'WXYZ'
);


	$AGI->stream_file($aud_file_loc);
//	OBTAINING AGENT NAME TO SEARCH IN DIRECTORY
        $invalid_input = True;
        $invalid_attempts = 0;
  
/*	$entered_digits = $AGI->get_data('custom/directory-total-prompt', 5, 3);

//	ARRAY RESULT PRINT
	$user_input = $entered_digits['result'];
	$dt = var_dump($user_input);
	$AGI->verbose("USER INPUT DATA TYPE $dt");
	$AGI->verbose("USER ENTERED KEYS $user_input");
*/
        while ($invalid_input)
		{
			$entered_digits = $AGI->get_data('custom/directory-total-prompt', 5, 3);
//      	EXTRACT DATA FROM ARRAY
     
			$user_input = $entered_digits['result'];
			$AGI->verbose("USER ENTERED KEYS $user_input");

        if ($user_input > 222)
		{
                $invalid_input = False;
				
        }else{
			$invalid_attempts++;
			if ($invalid_attempts == $max_inv_attempts){
					$AGI->verbose("========   MAX INVALID ENTRIES. GOING TO FAILOVER DESTINATION    =======");
					$invalid_input = False;
					$AGI->set_variable("POST_DEST",$post_dest);
					$AGI->set_variable("DEST_VALUE",$post_dest_value);
					$AGI->set_variable("CUST_ID", $customer_id);
					$final_audio_loc  = get_audio_location($final_audio, $mysqli, $AGI);
					$AGI->stream_file($final_audio);
					$AGI->exec('Gosub', 'directory,s,1');
					}
			else{
					$AGI->verbose("USER GAVE AN INVALID ENTRY");
					$repeat_audio_loc  = get_audio_location($repeat_audio, $mysqli, $AGI);
					$AGI->stream_file($repeat_audio_loc);
					continue;
				}
			}
	       }


	$digits = [];
	$digits[0] = floor($user_input / 100);
	$digits[1] = floor(($user_input % 100) / 10);
	$digits[2] = $user_input % 10;

	$letters = [];
	for ($i=0;$i<count($digits);$i++)
  	{	
	  	$AGI->verbose("DIGIT BEING CHECKED IS $digits[$i]");
  		if (isset($digitToLetter[$digits[$i]])) 
		{	
			$letters[$i] = $digitToLetter[$digits[$i]];
		}
		$AGI->verbose("USER INPUT $i IS $letters[$i]");
  	}

$query = "SELECT user_exten, fullname FROM directory_entries WHERE cust_id ='$customer_id' and directory_id='$directory_id'";
$result = $mysqli->query($query);
//$iteration = 0;

$matchingNames = array();

//while ($iteration < $result->num_rows){
while ($row =$result->fetch_assoc()){
	$name = $row['fullname'];
	$exten = $row['user_exten'];

    $AGI->verbose("=====================================");
    $AGI->verbose("USER NAME IS $name");
  	// Extract individual letters from the name
    $firstLetter = strtoupper(substr($name, 0, 1));
    $secondLetter = strtoupper(substr($name, 1, 1));
    $thirdLetter = strtoupper(substr($name, 2, 1));
    $AGI->verbose("FIRST LETTER IS $firstLetter");
    $AGI->verbose("SECOND LETTER IS $secondLetter");
    $AGI->verbose("THIRD LETTER IS $thirdLetter");
    $AGI->verbose("=====================================");
   
    // Compare with corresponding elements in the user input array
	if (is_int(strpos($letters[0], $firstLetter)) && is_int(strpos($letters[1], $secondLetter)) && is_int(strpos($letters[2], $thirdLetter)))
	{
		$matchingNames[$exten] = $name;
        	$AGI->verbose("NAME MATCHED $name");

	}
	/// ELSE STATEMENT FOR COMBINED IF STATEMENT

	else{
        $AGI->verbose("$name NOT MATCHED ");
            }
}
#$result->close();  
$result->free_result();
	foreach ($matchingNames as $xten=>$name)
	{
		$AGI->verbose("$xten BELONGS TO $name");
		$AGI->say_alpha($name);
		$choice = $AGI->get_data('dir-instr', 1, 3);
		$choice_result = $choice['result'];
		$AGI->verbose($choice_result);
		if ($choice_result == 1) 
		{
		        $AGI->set_variable("DIRECT_EXTEN", $xten);
  		      	$AGI->set_variable("CUST_ID", $customer_id);
        		$AGI->exec('Gosub', 'App-Extension-Dial,s,1');
			break;
  	
		//}elseif ($choice_result == *)
		}else
		{
		$AGI->verbose("ENTERED *");
		continue;
		}
	}
$AGI->verbose("CLOSING UP MYSQLI CONNECTION");
$mysqli->close();
?>
