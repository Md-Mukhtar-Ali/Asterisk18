#!/usr/bin/env /bin/php
<?php
require('phpagi.php');
error_reporting(E_ALL);

$script_name = 'ext_direct_dial.php';
//$db_ip = "127.0.0.1";
$db_ip = "localhost";
$db_user = "vitel_user";
$db_port = "3306";
$db_pass = "vitel_pbx123";

$inb_did                =       '';
$callerid       =       '';
$skip_playback  =       '';

// An array to store DIRECTORY NAMES incase the given EXTENSION is selected in multiple Directories
$dir_array      =       array();

// Create MySQL connection
$mysqli = new mysqli($db_ip, $db_user, $db_pass, "asterisk");
if ($mysqli->connect_errno) {
    fwrite($stderr, "Failed to connect to MySQL: " . $mysqli->connect_error . "\n");
    exit(1);
}
# create new Agi
$AGI = new AGI();

if (!$AGI) {
        // something went wrong
        exit(1);
}
        $AGI->verbose("MySQL connection Up");
        $AGI->verbose("script $script_name starting up");

   // set parameters
        $dial_ext       =       $argv[1];
        $ivr_id         =       $argv[2];
        $inb_did        =       $argv[3];
        $callerid       =       $argv[4];
        $customer_id    =       $argv[5];
        $dial_opt       =       $argv[6];

        $AGI->verbose("DIRECT DIAL OPTION IS $dial_opt");
        $AGI->verbose("DIRECT DIAL EXTENSION IS $dial_ext");
        $AGI->verbose("IVR ID IS $ivr_id");
        $AGI->verbose("INBOUND DID IS $inb_did");
        $AGI->verbose("CALLER ID IS $callerid");
        $AGI->verbose("CUSTOMER ID IS $customer_id");

        $AGI->verbose("call made to $inb_did from caller $callerid");

/*      $query = "SELECT context  FROM voicemail where mailbox='$customer_id-$dial_ext'";

        if ($result = $mysqli -> query($query)) {
        // Get field information for all fields
        //$AGI->verbose("RESULT IS $result");

        if ($result->num_rows == 0) {

        $AGI->verbose("NO DATA FOUND IN DB FOR THE GIVEN INBOUND DID");
        $AGI->exec('Gosub', 'ivr-menu,i,1');
    }
        while ($row = $result->fetch_assoc()) {
        $AGI->verbose("Result in loop $result");

        $Directory      =       $row["context"];
        $AGI->verbose("SELECTED DIRECTORY IS $Directory");
*/
/*      $application_dest       =       $row["dest"];
        $AGI->verbose("DEST APP IS $application_dest");

*/
    # set return variable

        //switch($result->dest)
        switch($dial_opt)
        {
case 'Enabled':
       	 $AGI->verbose("DIRECT DIAL WITHOUT SPECIFIC DIRECTORY ");
        //$query = "SELECT uniqueid  FROM voicemail where mailbox='$dial_ext'";
        //$query = "SELECT directory_id, directory_name, fullname  FROM directory_entries where user_exten='$dial_ext'";
	$query = "SELECT pbx_app,pbx_exten from pbx_used_extens where pbx_app='Extension' AND pbx_exten='$dial_ext'";        

	$result = $mysqli -> query($query);
        if ($result->num_rows == 0) {
        $AGI->verbose("CALLER HAS ENTERED AN INVALID EXTENSION");
        $AGI->exec('Gosub', 'ivr-menu,i,1');
	    }else{
        $AGI->set_variable("DIRECT_EXTEN", $dial_ext);
        $AGI->set_variable("CUST_ID", $customer_id);
        $AGI->exec('Gosub', 'App-Extension-Dial,s,1');
        //$AGI->exec("Gosub", "App-Extension-Dial,$inb_did,1");
        }
        break;
        

default:
        $AGI->verbose("Default Selection Mode ");
        //$query = "SELECT fullname, context FROM voicemail where mailbox='$dial_ext' and context='$dial_opt'";
        $query = "SELECT directory_id, directory_name, fullname FROM directory_entries where user_exten='$dial_ext' and directory_name='$dial_opt'";
        $result = $mysqli -> query($query);
        if ($result->num_rows == 0) {
        $AGI->verbose("NO DATA FOUND IN DB FOR THE GIVEN EXTENSION $dial_ext  IN DIRECTORY $dial_opt");
        $AGI->exec('Gosub', 'ivr-menu,i,1');
    }else{
        while ($row = $result->fetch_assoc()) {
        $i=1;
        $Directory      =       $row["directory_name"];
        $AGI->verbose("EXTEN FOUND IN DIRECTORY-$i : $Directory");
        $i++;
        if ("$dial_opt" == "$Directory"){
        $AGI->set_variable("DIRECT_EXTEN", $dial_ext);
        $AGI->set_variable("CUST_ID", $customer_id);
        $AGI->exec('Gosub', 'App-Extension-Dial,s,1');
        }
        else{
        $AGI->verbose("NO VALID CONTEXT FOUND IN DB FOR THE ENTERED DIRECT EXTENSION");
        $AGI->exec('Gosub', 'INVALID_DIRECT-DIAL,s,1');
//      $AGI->gosub('INVALID_DIRECT-DIAL', 's', '1','');
        }
        }
        }
        break;
}
/*}
}*/
        $result->free_result();
	$AGI->verbose("CLOSING UP MYSQLI CONNECTION");
        $mysqli->close();
//      $AGI->set_variable("IVR_RETN", $ivr_return);

?>

