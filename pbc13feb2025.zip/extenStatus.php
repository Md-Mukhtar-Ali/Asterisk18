#!/usr/bin/env /bin/php
<?php

$hintShow=shell_exec("asterisk -rx 'core show hints'");

$lines = explode("\n", $hintShow);

$unavailebleCount = 0;
$idleCount = 0;
$inUseCount = 0;



foreach($lines as $line){
if (preg_match('/^\s*(\d+)@\S+\s*:\s*\S+\/\S+\s+State:(\S+)/', $line, $matches)) {

//if (preg_match('/^\s*(\S+)@\S+\s*:\s*\S+\/\S+\s+State:(\S+)/', $line, $matches)) {
        $extension = $matches[1]; // Second column (extension)
        $state = $matches[2];     // Third column (state)

	if($state === "Unavailable"){
		$unavailebleCount++;
	}
	elseif($state === "Idle"){
		$idleCount++;
	}
	elseif($state === "InUse"){
		$idleCount++;
	}

        // Print the extracted values
        echo "Extension: $extension, State: $state\n";
    }

}

echo "\n Summary:\n";
echo "Unavaileble: $unavailebleCount\n";
echo "Idle: $idleCount\n";
echo "InUse : $inUseCount\n";

#print_r($hintShow);


?>
