#!/usr/bin/env /bin/php

<?php
require('phpagi.php');
error_reporting(E_ALL);

$db_ip = "localhost";
$db_user = "vitel_user";
$db_port = "3306";
$db_pass = "vitel_pbx123";

$script = "feature_codes.php";
$mysqli = new mysqli($db_ip, $db_user, $db_pass, "asterisk");
if ($mysqli->connect_errno) {
    fwrite($stderr, "Failed to connect to MySQL: " . $mysqli->connect_error . "\n");
    exit(1);
}
# create new Agi
$AGI = new AGI();

function checkPbxExten($AGI, $mysqli, $pbx_exten) {
        // Prepare and execute SQL query
        $pbx_exten_query="select * from pbx_used_extens where pbx_exten='$pbx_exten'";
        $AGI->verbose("$pbx_exten_query");
        // Fetch the result
        $pbx_result=$mysqli->query($pbx_exten_query);
        #$AGI->verbose("QUERY RESULT IS $pbx_result");
        #$AGI->verbose("QUERY FETCHED $pbx_result->num_rows ROWS");
        // Check if a result was found
        if ($pbx_result->num_rows == 0) {
        //return array("exists" => False);
              #  $AGI->verbose("EXTENSION $pbx_exten NOT FOUND");
                $pbx_result->free_result();
                $mysqli->close();
                return False;
        } else {
                //return array("exists" => True, "pbx_app" => $pbx_app);
                $AGI->verbose("EXTENSION $pbx_exten IS A VALID EXTENSION");
                $AGI->verbose("MySQL QUERY FAILED: $mysqli->error");
                $pbx_result -> free_result();
                return True;
        }
}

if (!$AGI) {
        // something went wrong
        exit(1);
}
$AGI->verbose("MySQL connection Up");
$AGI->verbose("$script starting up");

    // set parameters
        $feature_code   =       $argv[1];
        $caller         =       $argv[2];

$AGI->verbose("CHECKING FEATURE CODE FOR CALLER $caller");

        $feature_search_query = "SELECT * FROM featurecodes where customcode='$feature_code'";
        $AGI->verbose($feature_search_query);
        $fs_result = $mysqli->query($feature_search_query);

        if ($fs_result->num_rows > 0)
        {
                $fs_fieldinfo   =       $fs_result->fetch_assoc();
                $fc_name        =       $fs_fieldinfo["featurename"];
                $fc_enabled     =       $fs_fieldinfo["enabled"];

                #EXIT IF FEATURE IS NOT ENABLED
                if (!$fc_enabled)
                {
                        $AGI->verbose("FEATURE $fc_name IS NOT ENABLED");
                        exit(1);
                }else{
                        $AGI->verbose("GOING TO EXECUTE $fc_name FOR $caller");
			$dialNum = substr($feature_code, 1);
                        switch($fc_name){
                                case 'Atxfr':
                                $AGI->exec('Gosub', 'Attended_Transfer,'.$dialNum.',1');
                                break;

                                case 'Blindxfr':
                                $AGI->exec('Gosub', 'Blind_Transfer,'.$dialNum.',1');
                                break;

                                case 'Blacklist_LastCaller':
                                $AGI->exec('Gosub', 'Blacklist_LastCaller,'.$dialNum.',1');
                                break;

                                case 'DialSelfVM':
                                $AGI->exec('Gosub', 'DialSelfVM,'.$dialNum.',1');
                                break;

                                case 'DialOtherVM':
                                $AGI->exec('Gosub', 'DialOtherVM,'.$dialNum.',1');
                                break;

                                case 'EchoTest':
                                $AGI->exec('Gosub', 'EchoTest,'.$dialNum.',1');
                                break;

                                case 'Clock':
                                $AGI->exec('Gosub', 'Clock,'.$dialNum.',1');
                                break;

                                case 'ReadOutExten':
                                $AGI->exec('Gosub', 'ReadExtension,'.$dialNum.',1');
                                break;

                                case 'Spy':
                                $AGI->exec('Gosub', 'Spy,'.$dialNum.',1');
                                break;

                                case 'DND_Activate':
                                $AGI->exec('Gosub', 'DND_Activate,'.$dialNum.',1');
                                break;

                                case 'DND_Deactivate':
                                $AGI->exec('Gosub', 'DND_Deactivate,'.$dialNum.',1');
                                break;

                                case 'Toggle_DND':
                                $AGI->exec('Gosub', 'Toggle_DND,'.$dialNum.',1');
                                break;

                                case 'Toggle_FollowMe':
                                $AGI->exec('Gosub', 'Toggle_FollowMe,'.$dialNum.',1');
                                break;

                                case 'CF_Activate':
                                $AGI->exec('Gosub', 'CF_Activate,'.$dialNum.',1');
                                break;

                                case 'CF_Deactivate':
                                $AGI->exec('Gosub', 'CF_Deactivate,'.$dialNum.',1');
                                break;

                                case 'CF_NA_Activate':
                                $AGI->exec('Gosub', 'CF_NA_Activate,'.$dialNum.',1');
                                break;

                                case 'CF_NA_Deactivate':
                                $AGI->exec('Gosub', 'CF_NA_Deactivate,'.$dialNum.',1');
                                break;

                                case 'CF_Busy_Activate':
                                $AGI->exec('Gosub', 'CF_Busy_Activate,'.$dialNum.',1');
                                break;

                                case 'CF_Busy_Deactivate':
                                $AGI->exec('Gosub', 'CF_Busy_Deactivate,'.$dialNum.',1');
                                break;

                                case 'CW_Deactivate':
                                $AGI->exec('Gosub', 'CW_Deactivate,'.$dialNum.',1');
                                break;

                               case 'CW_Activate':
                                $AGI->exec('Gosub', 'CW_Activate,'.$dialNum.',1');
                                break;

                                case 'Blacklist_Number':
                                $AGI->exec('Gosub', 'Blacklist_Number,'.$dialNum.',1');
                                break;

                                case 'Remove_Number_From_Blacklist':
                                $AGI->exec('Gosub', 'Remove_Number_From_Blacklist,'.$dialNum.',1');
                                break;

                                case 'Blacklist_LastCaller':
                                $AGI->exec('Gosub', 'Blacklist_LastCaller,'.$dialNum.',1');
                                break;

                                case 'CallTrace':
                                $AGI->exec('Gosub', 'CallTrace,'.$dialNum.',1');
                                break;

                                default:
                                break;
                        }#switch
            }#exit if-else
        }else{

	$directed_feature_query = "select featurename, customcode,enabled from featurecodes where featurename in ('DirectVMDial', 'Direct_Call_Pickup')";#, 'PickupParkedCall')";
	$AGI->verbose($directed_feature_query);
	$directed_result = $mysqli->query($directed_feature_query);
	if ($directed_result -> num_rows > 0){
		while ($directedRow = $directed_result->fetch_assoc()){
		
			$fname = $directedRow["featurename"];
			$fcode = $directedRow["customcode"];
                        $fc_enabled = $directedRow["enabled"];     
                    

			$AGI->verbose("COMPARING WITH FNAME $fname AND FCODE $fcode");
			$code_len = strlen($fcode);
			$AGI->verbose("LENGTH OF '$fname' FEATURE CODE '$fcode' IS $code_len");
			$usercode = substr($feature_code, 0, $code_len);
			$userExten = substr($feature_code, $code_len);
			$AGI->verbose("COMPARING $fcode WITH CODE PART AS $usercode; EXTEN PART IS $userExten");
			if ($usercode == $fcode && checkPbxExten($AGI, $mysqli, $userExten)){

                                  if (!$fc_enabled) {
                                                     $AGI->verbose("FEATURE $fc_name IS NOT ENABLED");
                                                     exit(1);
                                                    }   
			 $AGI->exec('Gosub', $fname.','.$userExten.',1');
				exit();
			}else{continue;}
		}
	}
	$directed_result->free_result();
		$pickupParkQuery = "select featurename, customcode,enabled from featurecodes where featurename = 'PickupParkedCall'";
		$AGI->verbose($pickupParkQuery);
		$pickupParkedResult = $mysqli->query($pickupParkQuery);
		if ($pickupParkedResult -> num_rows > 0){


			$pickupPakredData = $pickupParkedResult->fetch_assoc();
			$fname = $pickupPakredData["featurename"];
			$fcode = $pickupPakredData["customcode"];
			$fc_enabled = $pickupPakredData["enabled"];


			$code_len = strlen($fcode);
			$AGI->verbose("LENGTH OF '$fname' FEATURE CODE '$fcode' IS $code_len");
                        $usercode = substr($feature_code, 0, $code_len);
                        $userExten = substr($feature_code, $code_len);
			$AGI->verbose("COMPARING $fcode WITH CODE PART AS $usercode EXTEN PART IS $userExten");
                        $AGI->Verbose("$fname is $fc_enabled");
                        if ($usercode == $fcode){

					 if (!$fc_enabled) {
                        				    $AGI->verbose("FEATURE $fc_name IS NOT ENABLED");
                        				    exit(1);
                					   }				   

				$AGI->exec('Gosub', 'PickupParkedCall,'.$userExten.',1');
			}
			else{
		              $AGI->verbose("WRONG DIAL");
  		              $AGI->exec('busy');
  			    }
		}
		$pickupParkedResult->free_result();
        }
$mysqli->close();
?>	
