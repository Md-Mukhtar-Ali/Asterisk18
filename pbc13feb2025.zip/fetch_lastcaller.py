#!/var/lib/asterisk/agi-bin/pyst_env/bin/python

from asterisk.agi import *
agi = AGI()
import MySQLdb

#import asterisk.agi
#agi = asterisk.agi.AGI()
db=MySQLdb.connect("localhost","vitel_user","vitel_pbx123","asterisk")
agi.verbose("python agi started")
script = "python agi started"
agi.verbose(script.lower())
agi.verbose(script.upper())

# Get variables set in dialplan
tenant = agi.get_variable('CUST_ID')
caller = agi.get_variable('CALLER')
exten = f"{tenant}-{caller}"
#caller = '700'
#exten = '7000'
#exten = "{}-{}".format(tenant, caller)
agi.verbose(f'CUST ID IS {tenant}')
agi.verbose(f'EXTENSION IS {exten}')

#query_sql='''select calldate, cnum, src from cdr_custom where dst_cnum in ('101','10001-105') order by calldate desc limit 1'''
query = f"select calldate, cnum, src from cdr_custom where dst_cnum in ('{caller}', '{exten}') order by calldate desc limit 1"
#db.query(query)
agi.verbose(f'{query}')
c=db.cursor()
c.execute(query)
#res = c.fetchone()
#res_ty = str(type(res))
#res_type = res_ty.split("'")
#agi.verbose(f'nowhere: {res_type[1]}')
res = c.fetchone()
agi.verbose(f'{res}')
res_type = str(type(res)).split("'")[1]
agi.verbose(f'nowhere: {res_type}')

if res_type == "NoneType":
	agi.verbose("No Data Found")
else:
	agi.verbose("Data Found")
	agi.verbose(f'Data Found {res[0]}')
	agi.verbose(f'{res[0]}')
	last_caller = str(res[1])
	agi.verbose(f'Row Data obtained is {last_caller}')
	last_call_time = str(res[0])
	agi.verbose(f'CALL TIME IS {last_call_time}')
	last_caller_src= str(res[2])
	agi.verbose(f'ROW CALL SRC DATA IS {last_caller_src}')

	agi.verbose(f'{last_caller} WAS THE LAST CALLER TO {exten}')
# Set variable, it will be available in dialplan
	agi.set_variable('LAST_CALLER_NUM', last_caller)
# Check if the caller is an Internal Caller
	query2 = f"""SELECT pbx_app FROM pbx_used_extens where cust_id='{tenant}' and pbx_exten in ('{last_caller}','{last_caller_src}')"""
	agi.verbose(f'{query2}')
	c2=db.cursor()
	c2.execute(query2)
	res2 = c2.fetchone()
	agi.verbose(f'{res2}')
	res2_type = str(type(res2)).split("'")[1]
	agi.verbose(f'App: {res2_type}')
	if res2_type == "NoneType":
		agi.verbose("LAST CALLER WAS NOT AN INTERNAL CALLER")
		agi.set_variable('INTERNAL_CALLER', 'no')
	else:
		agi.verbose("LAST CALLER WAS AN INTERNAL CALLER")
		agi.set_variable('INTERNAL_CALLER', 'yes')
db.close()
