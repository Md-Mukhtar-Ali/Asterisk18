#!/usr/bin/env /bin/php

<?php
require('phpagi.php');
require_once("mysql_connect.php");
require_once("modules.php");
error_reporting(E_ALL);
$verbosity = 0;
$mysqli = connectToDatabase();
if ($mysqli->connect_errno) {
    fwrite($stderr, "Failed to connect to MySQL: " . $mysqli->connect_error . "\n");
    exit(1);
}

echo "MySQL connected\n";
# create new Agi
$AGI = new AGI();

if (!$AGI) {
        // something went wrong
        exit;
}
$AGI->verbose("MySQL connection Up", $verbosity);
$AGI->verbose("script starting up", $verbosity);

    // set parameters
    $customer_id	=	$argv[1];
    $FollowMe_Name	=	$argv[2];

$AGI->verbose("call for \"$customer_id-$Exten\"");

// Check FollowMe Status from MySQL DB
$query = "SELECT * from followme where name='$FollowMe_Name'";
$result = $mysqli -> query($query);
if ($result->num_rows == 0)
{
	$AGI->set_variable("FM_STATUS", "no");
	$AGI->verbose("EXITING FOLLOWME CHECK AS FOLLOWME STATUS IS 'no'");
	}
if ($result->num_rows > 0) {
  // Get field information for all fields
    $AGI->verbose($result);
    
     while ($row = $result -> fetch_assoc()) {
	$FollowMe_status	=	$row["enable_followme"];
	$AGI->verbose("FollowMe status is $FollowMe_status");
	$only_dest		=	$row["only_destination"];
	$AGI->verbose("DIRECTLY DIAL DESTINATION STATUS $only_dest");
	$application_dest	=	$row["post_dest"];
	$app_dest_value		=	$row["post_dest_value"];
	$exten_ring_time	=	$row["exten_ringtime"];
	$grp_ring_time		=	$row["group_ringtime"];
	$cid_name_prefix	=	$row["cid_name_prefix"];
        $announce_id = $row["prompt_id"];
        $fm_moh = $row["musicclass"]; 
	$AGI->set_variable("POST_DEST", $application_dest);
	$AGI->set_variable("DEST_VALUE", $app_dest_value);

      // for announcement audio
       if($announce_id !=''){
                         $audio_file = get_audio_location($announce_id, $mysqli, $AGI);
                         $AGI->verbose("audio file location is $audio_file");
			}
        
  //announce code end
	if ($FollowMe_status == 'yes')
	{
	if ($only_dest == 'yes'){
		$AGI->exec('Gosub', 'final-destination,s,1');
			}
		else{
		$AGI->set_variable("FM_EXTEN_RING_TIME", $exten_ring_time); 
		$AGI->set_variable("GRP_RING_TIME", $grp_ring_time); 
		$AGI->set_variable("CID_NAME_PREFIX", $cid_name_prefix); 
		$AGI->set_variable("FOLLOWME_NAME", $FollowMe_Name);
		$AGI->set_variable("ONLY_DESTINATION", $only_dest);
                $AGI->set_variable("__ANNOUNCE_ID", $audio_file);
                $AGI->set_variable("__FM_MOH", $fm_moh);
	        #$AGI->exec('Goto', 'FollowMe-App-dial,'.$FollowMe_Name.',1');
                #$AGI->exec('Gosub', 'FollowMe-App-dial,'.$FollowMe_Name.',1');
		$AGI->exec('Gosub', 'followme-app,s,1');
	#	$AGI->exec('Gosub', 'followme_context,s,1'); 
		}
	}else 
	{
	$AGI->verbose("EXITING FOLLOWME CHECK AS FOLLOWME STATUS IS $FollowMe_status");
	}
  }
}

$result->free_result();
$mysqli->close();    
    # set return variable
?>
