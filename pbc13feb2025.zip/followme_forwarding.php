#!/usr/bin/env /bin/php
<?php
require('phpagi.php');
require_once("mysql_connect.php");
require_once("modules.php");
//require('include/phpagi.php');
error_reporting(E_ALL);
$verbosity = 0;
$mysqli = connectToDatabase();
if ($mysqli->connect_errno) {
    fwrite($stderr, "Failed to connect to MySQL: " . $mysqli->connect_error . "\n");
    exit(1);
}

echo "MySQL connected\n";
# create new Agi
$AGI = new AGI();

if (!$AGI) {
        // something went wrong
        exit;
}
$AGI->verbose("MySQL connection Up", $verbosity);
$AGI->verbose("script starting up", $verbosity);

$customer_id    = $argv[1];
$FollowMe_Name  = $argv[2];

$AGI->verbose("call for \"$customer_id-$Exten\"");

// Check FollowMe Status from MySQL DB
$query = "SELECT * from followme where name='$FollowMe_Name'";
$AGI->verbose("$query");
$result = $mysqli -> query($query);
if ($result->num_rows == 0){
  $AGI->set_variable("FM_STATUS", "no");
  $AGI->verbose("EXITING FOLLOWME CHECK AS FOLLOWME DETAILS NOT FOUND");
 }

if ($result->num_rows > 0) {
  $AGI->verbose($result);
  while ($row = $result -> fetch_assoc()) {
    $FollowMe_status        =       $row["enable_followme"];
    $AGI->verbose("FollowMe status is $FollowMe_status");
    $only_dest              =       $row["only_destination"];
    $AGI->verbose("DIRECTLY DIAL DESTINATION STATUS $only_dest");
    $application_dest       =       $row["post_dest"];
    $app_dest_value         =       $row["post_dest_value"];
    $exten_ring_time        =       $row["exten_ringtime"];
    $grp_ring_time          =       $row["group_ringtime"];
    $cid_name_prefix        = $row["cid_name_prefix"];
    $announce_id 		= $row["prompt_id"];
    $fm_moh 		= $row["musicclass"];

      // for announcement audio
    if($announce_id !=''){
       $audio_file = get_audio_location($announce_id, $mysqli, $AGI);
       $AGI->verbose("audio file location is $audio_file");
     }
    $AGI->set_variable("POST_DEST", $application_dest);
    $AGI->set_variable("DEST_VALUE", $app_dest_value);
    $AGI->Verbose("follow me status is $FollowMe_status");
    $AGI->set_variable("ONLY_DESTINATION", $only_dest);
    if($FollowMe_status == "yes") {
      // if ($only_dest == 'yes'){
        //   $AGI->exec('Gosub', 'final-destination,s,1');
       // }
//else{

// phone number fetching start

                                                        $phoneNumbers = array();
							$ordinal      = array();
							$timeout      = array();
							$number1="";
							$number2="";
							$number3="";
							$number4="";
							$member_timeout1="";
							$member_timeout2="";
							$member_timeout3="";
							$member_timeout4="";
// phone number fetching end
							$AGI->set_variable("__ANNOUNCE_ID", $audio_file);
                                                       $AGI->set_variable("__FM_MOH", $fm_moh);

                                                      $fm_number_query = "SELECT * FROM followme_numbers where name='$FollowMe_Name'";
                                                      $AGI->verbose("$fm_number_query");
                                                      $result2 = $mysqli -> query($fm_number_query);
                                                     // $AGI->verbose("$result2");
                                                      if ($result2->num_rows == 0){
                                                                         $AGI->verbose("FOLLOWME NUMBERS NOT FOUND");
                                                      }
                                                      else{
                                                        while ($row2 = $result2 -> fetch_assoc()) {
                                                                $sno            = $row2["sno"];
                                                                $cust_id        = $row2["cust_id"]; $AGI->verbose("Customer id $cust_id");
                                                                $name           = $row2["name"];    $AGI->verbose("Follow me name is $name");
                                                                $ordinal[]        = $row2["ordinal"]; $AGI->verbose("Follow me ordinal is $ordinal");
                                                                $phoneNumbers[]    = $row2["phonenumber"];
                                                                $timeout[]        = $row2["timeout"];$AGI->verbose("Follow me number timeout is $timeout");
                                                        }
                                                      }
                                                      $phonenumber_count = count($phoneNumbers);
                                                                $AGI->set_variable("PHONENUMBER_COUNT", $phonenumber_count);
                                                                $AGI->verbose("We have found $phonenumber_count member(s) in followme");
                                                                $AGI->verbose("Now fetching all member list");

                                                                for ($i = 0; $i < $phonenumber_count; $i++) {

                                                                                      ${"number" . $i} = $phoneNumbers[$i];
                                                                                      ${"member_timeout".$i} = $timeout[$i];
                                                                                      
                                                      
						          }
						      $AGI->verbose("Fisrt number is $number0 and timeout is $member_timeout0");
                                                      $AGI->set_variable("NUMBER0", $number0);
                                                      $AGI->set_variable("FM_MEMTIME0", $member_timeout0);

                                                      $AGI->verbose("Second number is $number1 AND timeout is $member_timeout1");
                                                      $AGI->set_variable("NUMBER1", $number1);
						      $AGI->set_variable("FM_MEMTIME1", $member_timeout1);

                                                      $AGI->verbose("Third number is $number2 AND timeout is $member_timeout2");
                                                      $AGI->set_variable("NUMBER2", $number2);
                                                      $AGI->set_variable("FM_MEMTIME2", $member_timeout2);


                                                      $AGI->verbose("Fourth number is $number3 AND timeout is $member_timeout3");
                                                      $AGI->set_variable("NUMBER3", $number3);
                                                      $AGI->set_variable("FM_MEMTIME3", $member_timeout3);

                                                      $AGI->verbose("Fifth number is $number4 AND timeout is $member_timeout4");
                                                      $AGI->set_variable("NUMBER4", $number4);
                                                      $AGI->set_variable("FM_MEMTIME4", $member_timeout4);


                $AGI->set_variable("__FM_CID_PREFIX", $cid_name_prefix);
                $AGI->set_variable("EXTEN_RING_TIME", $exten_ring_time);
                $AGI->set_variable("GRP_RING_TIME", $grp_ring_time);
		$AGI->set_variable("FOLLOWME_NAME", $FollowMe_Name);
		//$result -> free_result();
		//$mysqli -> close();
                $AGI->exec('Goto', 'followme_context,s,1');
                 
        }else
        {
        $AGI->verbose("EXITING FOLLOWME CHECK AS FOLLOWME STATUS IS $FollowMe_status");
        }
  }
}


$result -> free_result();
$mysqli -> close();
    # set return variable
?>

