#!/usr/bin/env /bin/php
<?php
require('phpagi.php');
error_reporting(E_ALL);

$script_name = 'get_annc_details.php';
//$db_ip = "127.0.0.1";
$db_ip = "localhost";
$db_user = "vitel_user";
$db_port = "3306";
$db_pass = "vitel_pbx123";

// Create MySQL connection
$mysqli = new mysqli($db_ip, $db_user, $db_pass, "asterisk");
if ($mysqli->connect_errno) {
    fwrite($stderr, "Failed to connect to MySQL: " . $mysqli->connect_error . "\n");
    exit(1);
}
# create new Agi
$AGI = new AGI();

if (!$AGI) {
        // something went wrong
        exit(1);
}
	$AGI->verbose("MySQL connection Up");
	$AGI->verbose("script $script_name starting up");

    // set parameters
	$annc_id 	=	$argv[1];
	$callerid	=	$argv[2];

	$AGI->verbose("REQUEST TO PLAY $annc_id from caller $callerid");

//  GET ANNOUNCEMENT DETAILS FOR THE GIVEN ANNC_ID
	$query = "SELECT *  FROM announcement where announcement_id='$annc_id'";
// write code to take calls from specific callerid

	if ($result = $mysqli -> query($query)) {
	// Get field information for all fields
	//$AGI->verbose("RESULT IS $result");

    if ($result->num_rows == 0) {

	$AGI->verbose("INVALID INPUT MODE");
	$AGI->exec('Gosub', 'terminate-call,s,1');
    }
	while ($row = $result->fetch_assoc()) {
	$AGI->verbose("Result in loop $result");

	$customer_id  	=	$row["cust_id"];
	$AGI->verbose("CUSTOMER ID IS $customer_id");

	$application_dest	=	$row["post_dest"];
	$AGI->verbose("DEST APP IS $application_dest");

	$app_dest_value	=	$row["dest_value"];
	$AGI->verbose("DEST VALUE IS $app_dest_value");

	$force_answer	=	$row["fanswer"];
	$AGI->verbose("FORCE ANSWER IS $force_answer");

	$moh_class	=	$row["mohclass"];
	$AGI->verbose("MOH CLASS FOR THE DID IS $moh_class");

	$force_ring	=	$row["ringing"];
	$AGI->verbose("RING BEFORE TRANSFER IS $force_ring");
	
	$proxy_caller_name = 	$row["set_cid_name"];
	$AGI->verbose("PROXY NAME SET TO CALLER IS $proxy_caller_name");

    # set return variable

	//switch($result->dest)
	switch($application_dest)
	{
// QUEUE START
	case 'Queue':
	
	$AGI->verbose("Queue Call Mode");
	$AGI->set_variable("MOH_CLASS", $moh_class);

  // SET POST DESTINATION FOR SELECTED QUEUE
        $query4 = "SELECT *  FROM queues where queue_id ='$app_dest_value'";

        if ($result4 = $mysqli -> query($query4)) {
        // Get field information for all fields
        //$AGI->verbose("RESULT IS $result4");

        if ($result4->num_rows == 0) {

        $AGI->verbose("NO DATA FOUND IN DB FOR THE GIVEN QUEUE ID");
        $AGI->exec('Gosub', 'terminate-call,s,1');
    }
        while ($row4 = $result4->fetch_assoc()) {
        $AGI->verbose("Result in loop $result");

        $queue_name             =       $row4["name"];
        $AGI->verbose("SELECTED QUEUE NAME IS $queue_name");

        $post_dest              =       $row4["post_dest"];
        $AGI->verbose("FINAL DESTINATION IS $post_dest");

        $post_dest_value        =       $row4["post_dest_value"];
        $AGI->verbose("FINAL DESTINATION VALUE IS $post_dest_value");

                }
        }
	$result4->free_result();
        $AGI->set_variable("SELECTED_QUEUE", $queue_name);
        $AGI->set_variable("POST_DEST",$post_dest);
        $AGI->set_variable("DEST_VALUE",$post_dest_value);


	$AGI->exec('Gosub', 'queue-call,s,1');
 	break;
// QUEUE END
	
// EXTENSIONS DIAL START
	 case 'Extension':
        $AGI->verbose("Extension Dial Mode");
        $AGI->set_variable("DIRECT_EXTN", $app_dest_value);
        $AGI->set_variable("CUST_ID", $customer_id);
        $AGI->exec('Gosub', 'App-Extension-Dial,s,1');
        break;


/*	case 'Extension':
	$AGI->verbose("Extension Dial Mode");
	$AGI->set_variable("DIRECT_EXTN", $app_dest_value);
	$AGI->exec('Gosub', 'direct-dial,s,1');
	break;
*/
// EXTENSION DIAL END

// DIRECTORY START
        case 'Directory':
        $AGI->verbose("Directory Mode");
        $AGI->set_variable("REQ_VM_CNTX", $app_dest_value);
        $AGI->exec('Gosub', 'directory,s,1');
        break;
// DIRECTORY END

// ANNOUNCEMENT START
        case 'Announce':
        $AGI->verbose("Announcement Mode");
	
	$query2 = "SELECT *  FROM announcement where announcement_id='$app_dest_value'";	

	if ($result2 = $mysqli->query($query2))
        {
        while ($row2 = $result2->fetch_assoc()){
        $customer_id	=       $row2["cust_id"];
        $audio_file_id	=       $row2["audio_file_id"];
        $skip_playback	=       $row2["allow_skip"];
        $return_to_ivr	=       $row2["return_ivr"];
        $disable_answer	=	$row2["noanswer"];
        $repeat_key	=	$row2["key_press_to_repeat"];

        $AGI->verbose("AUDIO FILE ID IS $audio_file_id");
        $AGI->verbose("SKIP PLAYBACK STATUS IS $skip_playback");
        $AGI->set_variable("SKIP_PLAYBACK", $skip_playback);
        $AGI->set_variable("CUST_ID", $customer_id);
        $AGI->set_variable("__IVR_RET", $return_to_ivr);
        $AGI->verbose("IVR RETURN is $return_to_ivr");
        $AGI->set_variable("__IVRS_ID", $ivr_id);
        $AGI->set_variable("DISABLE_ANS", $disable_answer);
        $AGI->set_variable("KEY_REPEAT", $repeat_key);
        
        $post_dest              =       $row2["post_dest"];
        $AGI->verbose("FINAL DESTINATION IS $post_dest");

        $post_dest_value        =       $row2["post_dest_value"];
        $AGI->verbose("FINAL DESTINATION VALUE IS $post_dest_value");

	$AGI->set_variable("POST_DEST",$post_dest);
	$AGI->set_variable("DEST_VALUE",$post_dest_value);

	$query1 = "SELECT File_Location  FROM pss_audio_files where File_id='$audio_file_id'";
	if ($result1 = $mysqli->query($query1)) 
	{
    	while ($row1 = $result1->fetch_assoc()) 
		{
	$aud_file_loc 	=	$row1["File_Location"];
    	$AGI->verbose("Audio File Location is $aud_file_loc");
        $AGI->set_variable("AUD_FILE_LOC", $aud_file_loc);
	$AGI->set_variable("IVRS_ID", $ivr_id);
    	$AGI->verbose("IVRS ID set to  $ivr_id");
      //$AGI->exec('Gosub', 'announcement,s,1(IVRS_ID)');

        $AGI->exec('Gosub', 'announcement,s,1');
		}
	}else{
    	$AGI->verbose("File path is missing");
	}
		}
	$result1->free_result();
	$result2->free_result();

	}       
 break;
// ANOUNCEMENT END

// IVR START
	case 'IVR':
	$AGI->verbose("IVR TRASFER MODE");
        $AGI->set_variable("__IVRS_ID", $app_dest_value);
	$AGI->exec('Gosub', 'ivr-menu,s,1');
	break;
// IVR END 

// TERMINATE-CALL START
	case 'Terminate-call':
	switch($app_dest_value) {
	case 'Busy':
	$AGI->verbose("BUSY  MODE");
	$AGI->exec('busy');
	break;
	case 'Congestion':
	$AGI->verbose("CONGESTION MODE");
	$AGI->exec('congestion');	
	break;
	default:
	$AGI->verbose("DEFAUL HANGUP MODE");
	$AGI->exec('Playback','en/goodbye');
	$AGI->exec('hangup');
	}
	break;
// TERMINATE-CALL END

// VOICEMAIL START
	case 'VoiceMail':
 	$AGI->verbose("VoiceMail Mode");
        $query3 = "SELECT context,mailbox  FROM voicemail where uniqueid='$app_dest_value'";
        if ($result3 = $mysqli->query($query3))
        {
        // Get field information for all fields
        //$AGI->verbose($result3);

        while ($row3 = $result3->fetch_assoc())
                {
        $vm_context	  =       $row3["context"];
        $vm_exten	  =       $row3["mailbox"];
        $AGI->verbose("VoiceMail Context is $vm_context");
        $AGI->verbose("VoiceMail Extension is $vm_exten");
        $AGI->set_variable("VM_CONTEXT", $vm_context);
        $AGI->set_variable("VM_EXTEN", $vm_exten);
        $AGI->set_variable("IVR_RET", $ivr_return);
        $AGI->exec('Gosub', 'voicemail,s,1');
        //$AGI->exec('Gosub', 'ivr-menu,s,skip');
		}
	}
	$result3->free_result();
	break;

// VOICEMAIL END
	default:	
	$AGI->verbose("Default Selection Mode ");
	}#switch
  }
}

  	$result->free_result();
	$AGI->verbose("FREEING UP MYSQLI CONNECTION");
    	$AGI->set_variable("IVR_RETN", $ivr_return);

?>
