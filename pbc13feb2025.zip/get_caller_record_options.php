#!/usr/bin/env /bin/php

<?php
require('phpagi.php');
//require('include/phpagi.php');
error_reporting(E_ALL);

//$db_ip = "127.0.0.1";
$db_ip = "localhost";
$db_user = "vitel_user";
$db_port = "3306";
$db_pass = "vitel_pbx123";

// Create MySQL connection
$mysqli = new mysqli($db_ip, $db_user, $db_pass, "asterisk");
if ($mysqli->connect_errno) {
    fwrite($stderr, "Failed to connect to MySQL: " . $mysqli->connect_error . "\n");
    exit(1);
}
# create new Agi
$AGI = new AGI();

if (!$AGI) {
        // something went wrong
$AGI->verbose("something went wrong");
        exit(1);
}
$AGI->verbose("MySQL connection Up");
$AGI->verbose("script starting up");

    $Tenant = $argv[1];
    $caller_exten = $argv[2];
    $call_type = $argv[3];

$query = "SELECT outbound_external, outbound_internal, callrecord_priority  from extension_options where exten='$caller_exten'";#  and cust_id='$Tenant'";
$result = $mysqli->query($query);
$fieldinfo = $result->fetch_assoc();
$outbound_internal_rec = $fieldinfo["outbound_internal"];
$outbound_external_rec = $fieldinfo["outbound_external"];
$caller_rec_priority = $fieldinfo["callrecord_priority"];

  $AGI->verbose("======================================");
  $AGI->verbose("OUTBOUND INTERNAL RECORDING FOR $caller_exten WAS SET TO $outbound_internal_rec");
  $AGI->verbose("OUTBOUND EXTERNAL RECORDING FOR $caller_exten WAS SET TO $outbound_external_rec");
  $AGI->verbose("======================================");
 
//  CALL RECORDING OPTIONS
    $caller_record_option = $call_type == 'internal'?$outbound_internal_rec:$outbound_external_rec;
    $AGI->set_variable("__CALLER", $caller_record_option);
    $AGI->set_variable("__CALLER_PRI", $caller_rec_priority);
$result->free_result();
$mysqli->close();
?> 
