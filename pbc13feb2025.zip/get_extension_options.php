#!/usr/bin/env /bin/php

<?php
require('phpagi.php');
//require('include/phpagi.php');
error_reporting(E_ALL);

//$db_ip = "127.0.0.1";
$db_ip = "localhost";
$db_user = "vitel_user";
$db_port = "3306";
$db_pass = "vitel_pbx123";

// Create MySQL connection
$mysqli = new mysqli($db_ip, $db_user, $db_pass, "asterisk");
if ($mysqli->connect_errno) {
    fwrite($stderr, "Failed to connect to MySQL: " . $mysqli->connect_error . "\n");
    exit(1);
}
# create new Agi
$AGI = new AGI();

if (!$AGI) {
        // something went wrong
$AGI->verbose("something went wrong");
        exit(1);
}
$AGI->verbose("MySQL connection Up");
$AGI->verbose("script starting up");

    // set parameters
    $Tenant = $argv[1];
    $Exten  = $argv[2];
    $call_type = $argv[3];
//$AGI->verbose("call for \"$Tenant$Exten\"");
$AGI->verbose("call for $Tenant $Exten");

//  Check Call Forward Status and Fetch Forward Number data from a MySQL table

//$query = "SELECT * FROM extension_options where id='$Tenant-$Exten'";
$query = "SELECT * FROM extension_options where exten='$Exten' ";
$result = $mysqli->query($query); 
  // Get field information for all fields
  // $AGI->verbose($result);
    
   // while ($fieldinfo = $result->fetch_assoc()) 
    $fieldinfo = $result->fetch_assoc(); 
 // $AGI->verbose($result);
    $exten_ring_time=$fieldinfo["exten_ring_time"];
    $EXTEN_CID=$fieldinfo["cid_num"];
    $FM_status=$fieldinfo["followme_status"];
    $VM_status=$fieldinfo["voicemail_status"];
    $CF_ring_time=$fieldinfo["call_fwd_ring_time"];
    $CFA_status=$fieldinfo["call_fwd_all"];
    $CFA_Num=$fieldinfo["callfwd_all_num"];
    $CW_status=$fieldinfo["callwaiting_status"];
    $CS_status=$fieldinfo["call_screening"];
    $DND_status=$fieldinfo["dnd_status"];
 
    $CFNA_status=$fieldinfo["call_fwd_na"];
    $CFNA_Num=$fieldinfo["callfwd_na_num"];

    $CFB_status=$fieldinfo["call_fwd_busy"];
    $CFB_Num=$fieldinfo["callfwd_busy_num"];

    $inbound_internal_rec = $fieldinfo["inbound_internal"];
//    $outbound_internal_rec = $fieldinfo["outbound_internal"];
    $inbound_external_rec = $fieldinfo["inbound_external"];
    $callee_rec_priority   = $fieldinfo["callrecord_priority"];
    $outbound_route = $fieldinfo["outbound_route_id"];
    $exten_call_limit= $fieldinfo["exten_call_limit"];
    $missedcallalert=$fieldinfo["missedcallalert"];
    $post_dest=$fieldinfo["postdest"];  
    $post_dest_value=$fieldinfo["postdest_value"];

    $AGI->verbose("======================================");
    $AGI->verbose("EXTENSION RING TIME IS FOR $Exten IS $exten_ring_time");
    $AGI->verbose("INBOUND INTERNAL RECORDING FOR $Exten WAS SET TO $inbound_internal_rec");
    $AGI->verbose("INBOUND EXTERNAL RECORDING FOR $Exten WAS SET TO $inbound_external_rec");
    $AGI->verbose("CALL RECORDING PRIORITY FOR $Exten IS $callee_rec_priority");
    $AGI->verbose("EXTENSION CALLERID IS $EXTEN_CID");
    $AGI->verbose("DND STATUS IS $DND_status");

    $AGI->verbose("FOLLOW-ME STATUS IS $FM_status");
    $AGI->verbose("VOICEMAIL STATUS IS $VM_status");

    $AGI->verbose("CALL FORWARD RING TIME IS $CF_ring_time");
    $AGI->verbose("UNCONDITIONAL CALL FORWARD STATUS IS $CFA_status");
    $AGI->verbose("CALLS OF $Exten BEING FORWARDED TO $CFA_Num");
    $AGI->verbose("CALL FORWARD - NO ANSWER STATUS IS $CFNA_status");
    $AGI->verbose("WHEN UNAVAILABLE, CALLS OF $Exten ARE FORWARDED TO $CFNA_Num");
    $AGI->verbose("CALL FORWARD - BUSY STATUS IS $CFB_status");
    $AGI->verbose("WHEN BUSY, CALLS OF $Exten ARE FORWARDED TO $CFB_Num");

    
    $AGI->verbose("CALL WAITING STATUS IS $CW_status");
    $AGI->verbose("CALL SCREENING STATUS IS $CS_status");
    $AGI->Verbose("Outbound route id is $outbound_route and call limit $exten_call_limit");
    $AGI->Verbose("Extension failover destination is $post_dest");
    $AGI->Verbose("Extension failover destination value $post_dest_value");

    $AGI->verbose("======================================");
  
$result->free_result();

//for transfer
$query1 = "SELECT * FROM extension_options where exten='$Exten' ";
$result = $mysqli->query($query1);

$mysqli->close();    
    # set return variable
    $AGI->set_variable("__EXTEN_RING_TIME", $exten_ring_time);
    $AGI->set_variable("__EXTEN_CID", $EXTEN_CID);
    $AGI->set_variable("__FM_STATUS", $FM_status);
    $AGI->set_variable("__VM_STATUS", $VM_status);
    $AGI->set_variable("__CW_STATUS", $CW_status);
    $AGI->set_variable("__CS_STATUS", $CS_status);
    $AGI->set_variable("__DND_STATUS", $DND_status);

    $AGI->set_variable("__CF_RNG_TM", $CF_ring_time);
    $AGI->set_variable("__CFA_STATUS", $CFA_status);
    $AGI->set_variable("__CFA_NUMBER", $CFA_Num);
    $AGI->set_variable("__CFNA_STATUS", $CFNA_status);
    $AGI->set_variable("__CFNA_NUMBER", $CFNA_Num);
    $AGI->set_variable("__CFB_STATUS", $CFB_status);
    $AGI->set_variable("__CFB_NUMBER", $CFB_Num);
    $AGI->set_variable("__OUTBOUND_ROUTE", $outbound_route);
    $AGI->set_variable("__EXTEN_CALL_LIMIT", $exten_call_limit);
    $AGI->set_variable("__MISSEDCALLALERT", $missedcallalert);
    $AGI->set_variable("__EXTEN_POST_DEST", $post_dest);
    $AGI->set_variable("__EXTEN_POST_DESTVALUE", $post_dest_value);
 
//  CALL RECORDING OPTIONS
    $record_option = $call_type == 'internal'?$inbound_internal_rec:$inbound_external_rec;
    $AGI->set_variable("__CALLEE",$record_option);
    $AGI->set_variable("__CALLEE_PRI", $callee_rec_priority);
?>
