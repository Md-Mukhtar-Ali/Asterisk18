#!/usr/bin/env /usr/bin/php
<?php
require('phpagi.php');
$verbosity = True;
require_once("mysql_connect.php");
error_reporting(E_ALL);
$script_name = 'get_inbound_did_recording_options.php';
$Inbound_DID    =       '';
$callerid       =       '';
$skip_playback  =       '';
$mysqli = connectToDatabase();
if ($mysqli->connect_errno) {
    fwrite($stderr, "Failed to connect to MySQL: " . $mysqli->connect_error . "\n");
    exit(1);
}
# create new Agi
$AGI = new AGI();

if (!$AGI) {
        // something went wrong
        exit(1);
}
        $AGI->verbose("MySQL connection Up");
        $AGI->verbose("script $script_name starting up");

    // set parameters
        $customer_id            =       $argv[1];
        $Inbound_DID            =       $argv[2];
        $callerid               =       $argv[3];
//  GET INBOUND ROUTING DETAILS FOR THE INBOUND DID
        $query = "SELECT *  FROM inbound_routes where Inbound_DID='$Inbound_DID'";
// write code to take calls from specific callerid
	$result = $mysqli -> query($query);
	if ($result->num_rows == 0) 
   {
        if ($verbosity){$AGI->verbose("NO DATA FOUND IN DB FOR THE GIVEN INBOUND DID");}
        $AGI->set_variable("CALL_SRC", $call_source);
        $AGI->exec('Gosub', 'terminate-call,s,1');
    }else{
	$row = $result->fetch_assoc();
	$call_recording_option  =       $row["call_recording"];
        $force_ring     	=       $row["ringing"];
        if ($verbosity){$AGI->verbose("RING BEFORE TRANSFER IS $force_ring");}

        if ($verbosity){$AGI->verbose("CALL RECORDING FOR INBOUND ROUTE $Inbound_DID SET TO $call_recording_option");}
        $AGI->set_variable("REC_OPT",$call_recording_option);
        $AGI->set_variable("FORCE_RING",$force_ring);
	}
?>	
