#!/usr/bin/env /usr/bin/php
<?php
require('phpagi.php');
$verbosity = True;
require_once("mysql_connect.php");
$script_name = 'get_inbound_routing.php';
//echo $script_name." IS RUNNING \n";
require('modules.php');
#require_once('modules.php');
error_reporting(E_ALL);

$Inbound_DID    =       '';
$callerid       =       '';
$skip_playback  =       '';

// Create MySQL connection
$mysqli = connectToDatabase();
if ($mysqli->connect_errno) {
    fwrite($stderr, "Failed to connect to MySQL: " . $mysqli->connect_error . "\n");
    exit(1);
}
# create new Agi
$AGI = new AGI();

if (!$AGI) {
        // something went wrong
        exit(1);
}
        $AGI->verbose("MySQL connection Up");
        $AGI->verbose("script $script_name starting up");

    // set parameters
	$customer_id		=	$argv[1];
        $Inbound_DID            =       $argv[2];
        $callerid               =       $argv[3];
	$call_source		=	$argv[4];

if ($verbosity){
        $AGI->verbose("call made to $Inbound_DID from caller $callerid");
	}
        $AGI->set_variable("INBOUND_DID", $Inbound_DID);
        $AGI->set_variable("CALLERID", $callerid);

//  GET INBOUND ROUTING DETAILS FOR THE INBOUND DID
        $query = "SELECT *  FROM inbound_routes where Inbound_DID='$Inbound_DID'";
// write code to take calls from specific callerid

        $result = $mysqli -> query($query); 

        if ($result->num_rows == 0) {

        if ($verbosity){$AGI->verbose("NO DATA FOUND IN DB FOR THE GIVEN INBOUND DID");}
	$AGI->set_variable("CALL_SRC", $call_source);
        $AGI->exec('Gosub', 'terminate-call,s,1');
    }else{
        $row = $result->fetch_assoc();

        $customer_id    =       $row["cust_id"];
        if ($verbosity){$AGI->verbose("CUSTOMER ID IS $customer_id");}

        $incomingCID    =       $row["cidnum"];
        if ($verbosity){$AGI->verbose("INCOMING CID IS $incomingCID");}

        $application_dest       =       $row["dest"];
        if ($verbosity){$AGI->verbose("DEST APP IS $application_dest");}

        $app_dest_value =       $row["dest_value"];
        if ($verbosity){$AGI->verbose("DEST VALUE IS $app_dest_value");}

        $force_answer   =       $row["fanswer"];
        if ($verbosity){$AGI->verbose("FORCE ANSWER IS $force_answer");}

        $moh_class      =       $row["mohclass"];
        if ($verbosity){$AGI->verbose("MOH CLASS FOR THE DID IS $moh_class");}
$AGI->verbose("testing==================");
        $force_ring     =       $row["ringing"];
        if ($verbosity){$AGI->verbose("RING BEFORE TRANSFER IS $force_ring");}
$AGI->verbose("testing1==================");
       # $proxy_caller_name =    $row["set_cid_name"];
        #if ($verbosity){$AGI->verbose("PROXY NAME SET TO CALLER IS $proxy_caller_name");}
//$AGI->verbose("testing2==================$proxy_caller_name");
// SET CALLER NAME PREFIX GIVEN IN INBOUND ROUTES
        $cid_name_prefix        =       $row["cid_name_prefix"];
        if ($verbosity){$AGI->verbose("CID(NAME) PREFIX FOR $Inbound_DID SET TO $cid_name_prefix");}


        $call_recording_option  =       $row["call_recording"];
        if ($verbosity){$AGI->verbose("CALL RECORDING FOR INBOUND ROUTE $Inbound_DID SET TO $call_recording_option");}
        $AGI->set_variable("CID_NAME_PREFIX",$cid_name_prefix);
        $AGI->set_variable("CALL_SRC", $call_source);
        $AGI->set_variable("MOH_CLASS", $moh_class);
        $AGI->set_variable("REC_OPT",$call_recording_option);
	$result->free_result();
  } 
    # set return variable
        //switch($result->dest)
        
if($incomingCID && $incomingCID != $callerid){
                   		  $AGI->verbose("CALLER ID IS NOT MATCHED");
                                  $AGI->set_variable("CALL_SRC", $call_source);
                                  $AGI->exec('Gosub', 'terminate-call,s,1');
            			}
else {               
	
	switch($application_dest)
        {
// QUEUE START
      case 'Queue':
	queue($mysqli, $AGI, $moh_class, $customer_id, $app_dest_value);
        break;
// QUEUE END

// EXTENSIONS DIAL START
      case 'Extension':
        if ($verbosity){$AGI->verbose("Extension Dial Mode");}
        $AGI->set_variable("DIRECT_EXTEN", $app_dest_value);
        $AGI->set_variable("CUST_ID", $customer_id);
       // $AGI->set_variable("INBOUND_DID", $Inbound_DID);
	$AGI->set_variable("CALL_SRC", $call_source);
        $AGI->exec('Gosub', 'App-Extension-Dial,s,1');
        break;
// EXTENSION DIAL END

// DIRECTORY START
      case 'Directory':
	directory($mysqli, $AGI, $app_dest_value, $customer_id, $call_source);
        break;
// DIRECTORY END

// ANNOUNCEMENT START
        case 'Announce':
        if ($verbosity){$AGI->verbose("Announcement Mode");}

        $query2 = "SELECT *  FROM announcement where announcement_id='$app_dest_value'";

        if ($result2 = $mysqli->query($query2))
        {
        // Get field information for all fields
        while ($row2 = $result2->fetch_assoc())
                {
        $customer_id    =       $row2["cust_id"];
        $audio_file_id  =       $row2["audio_file_id"];
        $skip_playback  =       $row2["allow_skip"];
        $return_to_ivr  =       $row2["return_ivr"];
        $disable_answer =       $row2["noanswer"];
        $repeat_key     =       $row2["key_press_to_repeat"];

        $post_dest              =       $row2["post_dest"];
        if ($verbosity){$AGI->verbose("FINAL DESTINATION IS $post_dest");}

        $post_dest_value        =       $row2["post_dest_value"];
        if ($verbosity){$AGI->verbose("FINAL DESTINATION VALUE IS $post_dest_value");}

        if ($verbosity){$AGI->verbose("AUDIO FILE ID IS $audio_file_id");
        $AGI->verbose("IVR RETURN is $return_to_ivr");
        $AGI->verbose("SKIP PLAYBACK STATUS IS $skip_playback");}
        $AGI->set_variable("SKIP_PLAYBACK", $skip_playback);
        $AGI->set_variable("CUST_ID", $customer_id);
        $AGI->set_variable("IVR_RET", $return_to_ivr);
        $AGI->set_variable("IVRS_ID", $ivr_id);
        $AGI->set_variable("DISABLE_ANS", $disable_answer);
        $AGI->set_variable("KEY_REPEAT", $repeat_key);


        $AGI->set_variable("POST_DEST",$post_dest);
        $AGI->set_variable("DEST_VALUE",$post_dest_value);

        $query1 = "SELECT File_Location  FROM pss_audio_files where File_id='$audio_file_id'";
        if ($result1 = $mysqli->query($query1))
        {
        // Get field information for all fields
        while ($row1 = $result1->fetch_assoc())
                {
        $aud_file_loc   =       $row1["File_Location"];
        if ($verbosity){$AGI->verbose("Audio File Location is $aud_file_loc");}
        $AGI->set_variable("AUD_FILE_LOC", $aud_file_loc);
        $AGI->set_variable("IVRS_ID", $ivr_id);
        if ($verbosity){$AGI->verbose("IVRS ID set to  $ivr_id");}

      //$AGI->exec('Gosub', 'announcement,s,1(IVRS_ID)');
	$AGI->set_variable("CALL_SRC", $call_source);
        $AGI->exec('Gosub', 'announcement,s,1');
                }
        }else{
        if ($verbosity){$AGI->verbose("File path is missing");}
        }
                }
        }
 break;
// ANOUNCEMENT END

// IVR START
        case 'IVR':
        if ($verbosity){$AGI->verbose("IVR TRASFER MODE FOR $Inbound_DID");}
        $AGI->set_variable("IVRS_ID", $app_dest_value);
        //$AGI->set_variable("INBOUND_DID", $Inbound_DID);
        //$AGI->set_variable("EXTEN", $Inbound_DID);
	$AGI->set_variable("CALL_SRC", $call_source);
        $AGI->exec('Gosub', 'ivr-menu,s,1');
        //$AGI->exec("Gosub", "ivr-menu,$Inbound_DID,1");
        break;
// IVR END

// TERMINATE-CALL START
        case 'Terminate-call':
        switch($app_dest_value) {
        case 'Busy':
        if ($verbosity){$AGI->verbose("BUSY  MODE");}
        $AGI->exec('busy');
        break;
        case 'Congestion':
        if ($verbosity){$AGI->verbose("CONGESTION MODE");}
        $AGI->exec('congestion');
        break;
        default:
        if ($verbosity){$AGI->verbose("DEFAUL HANGUP MODE");}
        $AGI->exec('Playback','en/goodbye');
        $AGI->exec('hangup');
        }
        break;
// TERMINATE-CALL END

// VOICEMAIL START
        case 'Voicemail':
        if ($verbosity){$AGI->verbose("VoiceMail Mode");}
        $query3 = "SELECT context,mailbox  FROM voicemail where mailbox='$app_dest_value'";
        if ($result3 = $mysqli->query($query3))
        {
        // Get field information for all fields
        while ($row3 = $result3->fetch_assoc())
                {
        $vm_context       =       $row3["context"];
        $vm_exten         =       $row3["mailbox"];
        if ($verbosity){$AGI->verbose("VoiceMail Context is $vm_context");
        		$AGI->verbose("VoiceMail Extension is $vm_exten");}
        $AGI->set_variable("VM_CONTEXT", $vm_context);
        $AGI->set_variable("VM_EXTEN", $vm_exten);
        $AGI->set_variable("IVR_RET", $ivr_return);
	$AGI->set_variable("CALL_SRC", $call_source);
        //$AGI->set_variable("INBOUND_DID", $Inbound_DID);
        //$AGI->exec('Gosub', 'voicemail,s,1');
        $AGI->exec('Gosub', 'vm-local-context,'.$vm_exten.',1');
        //$AGI->exec('Gosub', 'ivr-menu,s,skip');
                }
        }
        break;

// VOICEMAIL END

// CONFERENCE START
        case 'Conference':
        if ($verbosity){$AGI->verbose("ENTERING CONFERENCE MODE");}
	conference($mysqli, $AGI, $app_dest_value, $customer_id);

        if ($verbosity){$AGI->verbose("CONFERENCE MODE COMPLETED");}
        break;
// CONFERENCE END

// RINGGROUP START
        case 'RingGroup':
        ringgroup($mysqli, $AGI, $app_dest_value, $customer_id);
        break;

// RINGGROUP END

// TIME CONDITION - SCHEDULER START
        case 'TimeCondition':

        $AGI->verbose("TIME GROUPS & CONDITION BASED SCHEDULER MODULE");
        $AGI->set_variable("CALL_SRC", $call_source);
        $AGI->set_variable("TIME_CONDITION", $app_dest_value);
//        $AGI->set_variable("CUST_ID", $customer_id);
        $AGI->exec('Gosub', 'time-condition,s,1');
        break;
// TIME CONDITION - SCHEDULER END


// PAGING START
        case 'Paging':
        paging($mysqli, $AGI, $app_dest_value, $customer_id);
        break;

// PAGING END


        default:
        $AGI->verbose("INVALID SELECTION FOR INBOUND DID - $Inbound_DID");
	$AGI->set_variable("terminate", $app_dest_value);
	}
}
function is_ext_avail($AGI, $extnum) {
  /*      global $ampuser;

        if($extnum == $ampuser) {
                $status = 1;
                $extstate_result = "INUSE_ORIGINATOR";
                debug("EXTENSION_STATE: $status ($extstate_result)", 1);
                return $status;
        }
  */
	$AGI->verbose("CHECKING EXTEN STATUS OF $extnum");
        $extstate_result  = $AGI->get_variable('EXTENSION_STATE($extnum@internal)');
	$AGI->verbose("EXTEN $extnum IS  $extstate_result[result]");
	foreach($extstate_result as $a=>$data){	$AGI->verbose("$a=>$data");}
        switch ($extstate_result) {
                case "NOT_INUSE":
                        $status = 0;
                        break;
                case "INUSE":
                        $status = 1;
                        break;
                case "BUSY":
                        $status = 2;
                        break;
                case "RINGING":
                        $status = 8;
                        break;
                case "RINGINUSE":
                        $status = 9;
                        break;
                case "HOLDINUSE":
                        $status = 17;
                        break;
                case "ONHOLD":
                        $status = 16;
                        break;
                case "UNAVAILABLE":
                case "UNKNOWN":
                default:
                        $status = 4;
        }
        debug("EXTENSION_STATE: $status ($extstate_result)", 1);
        return $status;
}
        $mysqli->close();
//      $AGI->set_variable("IVR_RETN", $ivr_return);
?>

