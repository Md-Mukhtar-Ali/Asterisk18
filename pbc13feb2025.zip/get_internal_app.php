#!/usr/bin/env /bin/php
<?php
require('phpagi.php');
require_once("mysql_connect.php");
$script = 'get_internal_app.php';
$verbosity = True;
error_reporting(E_ALL);
// Create MySQL connection
$mysqli = connectToDatabase();

# create new Agi
$AGI = new AGI();
if (!$AGI) {
$AGI->verbose("something went wrong");
        exit(1);}
$AGI->verbose("$script starting up");

if ($mysqli->connect_errno) {
    fwrite($stderr, "Failed to connect to MySQL: " . $mysqli->connect_error . "\n");
    exit(1);}
$AGI->verbose("MySQL connection Up");

// set parameters
$Tenant = $argv[1];
$dialed_exten = $argv[2];

$query = "SELECT pbx_app FROM pbx_used_extens where pbx_exten='$dialed_exten'";
$AGI->verbose($query);
$result = $mysqli->query($query);

$fieldinfo = $result->fetch_assoc();
$pbx_app = $fieldinfo["pbx_app"];

$AGI->verbose("APPLICATION IS '$pbx_app' FOR EXTENSION '$dialed_exten'");

$result -> free_result();
$mysqli -> close();

    # set return variable
$AGI->set_variable("PBX_DIAL_APP", $pbx_app);
?>

