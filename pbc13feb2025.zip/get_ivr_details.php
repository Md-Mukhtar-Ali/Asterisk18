#!/usr/bin/env /bin/php
<?php
require('phpagi.php');
require('modules.php');
require_once("mysql_connect.php");
error_reporting(E_ALL);

$script_name = 'get_ivr_details.agi';

// Create MySQL connection
$mysqli = connectToDatabase();
if ($mysqli->connect_errno) {
    fwrite($stderr, "Failed to connect to MySQL: " . $mysqli->connect_error . "\n");
    exit(1);
}
# create new Agi
$AGI = new AGI();

if (!$AGI) {
        // something went wrong
        exit(1);
}
$AGI->verbose("MySQL connection Up");
$AGI->verbose("script starting up");

    // set parameters
    $ivr_id = $argv[1];
$AGI->verbose("call landed on IVR ID \"$ivr_id\" \n");

//  Check Call Forward Status and Fetch Forward Number data from a MySQL table

$query = "SELECT *  FROM ivr_details where ivr_id=$ivr_id";
if ($result = $mysqli -> query($query)) {
  // Get field information for all fields
	$data = print_r($row, true); // Convert array to string for verbose
	$AGI->verbose("Result in loop $data");

	//$AGI->verbose($result);
    
    while ($fieldinfo = $result -> fetch_assoc()) {
    //$AGI->verbose("Result in loop $result");

    $customer_id	=	$fieldinfo["cust_id"];
    $AGI->verbose("CUSTOMER ID IS $customer_id");

    $ivr_name		=	$fieldinfo["name"];
    $AGI->verbose($ivr_name);

    //$announcment_file	=	$fieldinfo["announcement"];
    $announcment_id	=	$fieldinfo["announcement"];
    $announcment_file	=	get_audio_location($announcment_id, $mysqli, $AGI);
    $AGI->verbose("WELCOME ANNOUNCEMENT $announcment_file");

    //$menu_audio 	=	$fieldinfo["menu_options_recording"];
    $menu_file_id 	=	$fieldinfo["menu_options_recording"];
    $menu_audio 	=	get_audio_location($menu_file_id, $mysqli, $AGI);
    $AGI->verbose("MENU OPTIONS FILE IS $menu_audio");

    $direct_dial	=	$fieldinfo["directdial"];
    $AGI->verbose("DIRECT DIAL CHOICE IS $direct_dial");

    $inv_loop_limit	=	$fieldinfo["invalid_loops"];
    $AGI->verbose($inv_loop_limit);

    //$inv_retry_record	=	$fieldinfo["invalid_retry_recording"];
    $inv_retry_id	=	$fieldinfo["invalid_retry_recording"];
    $inv_retry_record	=	get_audio_location($inv_retry_id, $mysqli, $AGI);
    $AGI->verbose("INVALID RETRY AUDIO IS $inv_retry_record");

    $inv_dest		=	$fieldinfo["invalid_destination"];
    $AGI->verbose("invalid_destination $inv_dest");

    $inv_dest_value	=	$fieldinfo["inv_dest_value"];
    $AGI->verbose("invalid_destination value $inv_dest_value");

    $timeout_enabled 	=  	$fieldinfo["timeout_enabled"];
    $AGI->verbose("timeout_enabled $timeout_enabled");

    //$inv_recording   	=  	$fieldinfo["invalid_recording"];
    $inv_record_id   	=  	$fieldinfo["invalid_recording"];
    $inv_recording   	=  	get_audio_location($inv_record_id, $mysqli, $AGI);
    $AGI->verbose("FINAL INVALID RECORDING IS $inv_recording");

    $return_from_VM    	=  	$fieldinfo["retvm"];
    $AGI->verbose("retvm $return_from_VM");

    $timeout_dur    	=  	$fieldinfo["timeout_time"];
    $AGI->verbose("timeout_time $timeout_dur");

    //$timeout_recording	=  	$fieldinfo["timeout_recording"];
    $timeout_record_id	=  	$fieldinfo["timeout_recording"];
    $timeout_recording	=  	get_audio_location($timeout_record_id, $mysqli, $AGI);
    $AGI->verbose("FINAL TIMEOUT RECORDING IS $timeout_recording");

    //$timeout_retry_audio=  	$fieldinfo["timeout_retry_recording"];
    $timeout_retry_id   =  	$fieldinfo["timeout_retry_recording"];
    $timeout_retry_audio=  	get_audio_location($timeout_retry_id, $mysqli, $AGI);
    $AGI->verbose("TIMEOUT RETRY RECORDING IS $timeout_retry_audio");

    $timeout_dest    	=  	$fieldinfo["timeout_destination"];
    $AGI->verbose("timeout_destination $timeout_dest");

    $timeout_dest_value	=  	$fieldinfo["timeout_dest_value"];
    $AGI->verbose("timeout_dest_value $timeout_dest_value");

    $timeout_loop_limit	=  	$fieldinfo["timeout_loops"];
    $AGI->verbose("timeout_loops $timeout_loop_limit");

    $timeout_appnd_ANC 	=	$fieldinfo["timeout_append_announce"];
    $AGI->verbose($timeout_appnd_ANC);

    $inv_appnd_annc  	=  	$fieldinfo["invalid_append_announce"];
    $AGI->verbose($inv_appnd_annc);

    $timeout_ivr_ret 	=  $fieldinfo["timeout_ivr_ret"];
    $AGI->verbose($timeout_ivr_ret);

    $inv_ivr_ret     	=  $fieldinfo["invalid_ivr_ret"];
    $AGI->verbose("invalid_ivr_ret $inv_ivr_ret");

    $alertinfo		=  $fieldinfo["alertinfo"];
    $AGI->verbose("alertinfo $alertinfo");

    $ring_volume	=  $fieldinfo["rvolume"];
    $AGI->verbose("rvolume $ring_volume");

    $strict_dial_timout	=  $fieldinfo["strict_dial_timeout"];
    $AGI->verbose("strict_dial_timeout $strict_dial_timout");
    
  }
  $result -> free_result();
}

$mysqli -> close();    
    # set return variable
	$AGI->set_variable("CUST_ID", $customer_id);
	$AGI->set_variable("TIMEOUT_TIME", $timeout_dur);
	$AGI->set_variable("DIAL_OPT", $direct_dial);
	$AGI->set_variable("INV_DEST", $inv_dest);
	$AGI->set_variable("INV_DEST_VALUE", $inv_dest_value);
	
	$AGI->set_variable("TMOUT_DEST", $timeout_dest);
	$AGI->set_variable("TMOUT_DEST_VALUE", $timeout_dest_value);
//	$AGI->set_variable("CUST_ID", $customer_id);

    $AGI->set_variable("PRE_IVR_AUDIO", $announcment_file);
    $AGI->set_variable("TM_LOOPS_LIMIT", $timeout_loop_limit);
    $AGI->set_variable("INV_LOOPS_LIMIT", $inv_loop_limit);
    $AGI->set_variable("MENU_AUDIO", $menu_audio);
    $AGI->set_variable("INVALID_RETRY_AUDIO", $inv_retry_record);
    $AGI->set_variable("INVALID_RESPONSE_AUDIO", $inv_recording);

    $AGI->set_variable("TM_RESPONSE_AUDIO", $timeout_recording);
    $AGI->set_variable("TM_RETRY_AUDIO", $timeout_retry_audio);
    $AGI->set_variable("IVRS_ID", $ivr_id);
    $AGI->set_variable("RET_FM_VM", $return_from_VM);
    
?>
