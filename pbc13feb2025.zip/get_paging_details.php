#!/usr/bin/env /bin/php

<?php
require('phpagi.php');
require('modules.php');
require_once("mysql_connect.php");
$script = 'get_paging_details.php';
$verbosity = True;
error_reporting(E_ALL);
// Create MySQL connection
$mysqli = connectToDatabase();

# create new Agi
$AGI = new AGI();
if (!$AGI) {
$AGI->verbose("something went wrong");
        exit(1);}
$AGI->verbose("$script starting up");
    
if ($mysqli->connect_errno) {
    fwrite($stderr, "Failed to connect to MySQL: " . $mysqli->connect_error . "\n");
    exit(1);}
$AGI->verbose("MySQL connection Up");

// set parameters
$Tenant = $argv[1];
$page_id = $argv[2];

$query = "SELECT * FROM paging_details where cust_id='$Tenant' and page_exten='$page_id'";
    $AGI->verbose($query);
$result = $mysqli->query($query);
    
    while ($fieldinfo = $result->fetch_assoc()) {
    $page_exten = $fieldinfo["page_exten"];
    $description = $fieldinfo["description"];
    $device_list = $fieldinfo["device-list"];
    $initial_prompt = $fieldinfo["prompt_id"];
    $busy_extens = $fieldinfo["busy_extens"];
    $duplex = $fieldinfo["duplex"];
  }

	$audio_file_loc = get_audio_location($initial_prompt, $mysqli, $AGI);
	if ($verbosity){
    $AGI->verbose("PAGE EXTEN NUMB IS $page_exten");
    $AGI->verbose("PAGING NAME IS $description");
    $AGI->verbose("DEVICE LIST IS $device_list");
    $AGI->verbose("INITIAL ALERT TONE IS $audio_file_loc");
    $AGI->verbose("HANDLE BUSY EXTENSIONS TO  BE $busy_extens DIALED");
    $AGI->verbose("ENABLE DUPLEX - $duplex");}
$result -> free_result();
$mysqli -> close();    

//	$paging_exten_arry  =       explode("-", $device_list);
//        $len_grp_list   =       count($grp_exten_ary);
//        $dial_string = '';


/*        if ($len_grp_list == 0){
        $AGI->verbose("PAGING LIST IS EMPTY");
        }else{
*/
    # set return variable
        $AGI->set_variable("PAGING_DIAL_STRING", $device_list);
        $AGI->set_variable("AUD_FILE_LOC", $audio_file_loc);
        $AGI->set_variable("CALL_SRC", "INT_PAGING_$page_exten");
    	$AGI->set_variable("SKIPBUSY_AGENT", $busy_extens);
    	$AGI->set_variable("ENABLE_DUPLEX", $duplex);
        $AGI->exec('Gosub', 'page-dial,s,1');
  

?>
