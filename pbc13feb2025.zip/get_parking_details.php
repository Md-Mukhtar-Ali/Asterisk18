#!/usr/bin/env /bin/php

<?php
require('phpagi.php');
require('modules.php');
require_once("mysql_connect.php");
$script = 'get_parking_details.php';
$enable_log = "Y";
$verbosity = True;
error_reporting(E_ALL);
// Create MySQL connection
$mysqli = connectToDatabase();

# create new Agi
$AGI = new AGI();
if (!$AGI) {
$AGI->verbose("something went wrong");
        exit(1);}
$AGI->verbose("$script starting up");
    
if ($mysqli->connect_errno) {
    fwrite($stderr, "Failed to connect to MySQL: " . $mysqli->connect_error . "\n");
    exit(1);}
$AGI->verbose("MySQL connection Up");

// set parameters
$ParkingLotName = $argv[1];
$Tenant = $argv[2];

$query = "SELECT * FROM parking_details where parking_lot_name='$ParkingLotName'";# and  cust_id='$Tenant'";
    $AGI->verbose($query);
$result = $mysqli->query($query);
    
    while ($fieldinfo = $result->fetch_assoc()) {
    $cid_name_prefix = $fieldinfo["callerid_prefix"];
    $failover_dest = $fieldinfo["failover_dest"];
    $failover_dest_value = $fieldinfo["dest_value"];
    $timeout_dest = $fieldinfo["timeout_dest"];
    $timeout_dest_value = $fieldinfo["timeout_dest_value"];
    $return_to_parker = $fieldinfo["return_to_origin"];
        $prompt_id      = $fieldinfo["prompt_id"];
        $aud_file_loc  = get_audio_location($prompt_id, $mysqli, $AGI);
    $AGI->verbose("RETURN FROM PARKING ANNOUNCEMENT $aud_file_loc");
    $AGI->verbose("RETURN TO PARKER IS SET TO $return_to_parker");
        $AGI->set_variable("AUDIO_FILE_LOC", $aud_file_loc);
        $AGI->set_variable("RETURN_TO_PARKER", $return_to_parker);

if ($verbosity){
    $AGI->verbose("CID NAME PREFIX IS $cid_name_prefix");
    $AGI->verbose("FAIL-OVER DEST IS $failover_dest");
    $AGI->verbose("FAIL-OVER DEST VALUE IS $failover_dest_value");
    $AGI->verbose("TIME-OUT DEST IS $timeout_dest");
    $AGI->verbose("TIME-OUT DEST VALUE IS $timeout_dest_value");
    $AGI->verbose("VOICEMAIL CONTEXT IS $VM_context");}
  }
$result -> free_result();
$mysqli -> close();    

    # set return variable
    $AGI->set_variable("CID_NAME_PREFIX", $cid_name_prefix);
    $AGI->set_variable("FAIL_OVER_DEST", $failover_dest);
    $AGI->set_variable("FAIL_OVER_VALUE", $failover_dest_value);
    $AGI->set_variable("TIME_OUT_DEST", $timeout_dest);
    $AGI->set_variable("TIME_OUT_VALUE", $timeout_dest_value);

?>
