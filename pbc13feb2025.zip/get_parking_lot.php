#!/usr/bin/env /bin/php
<?php
require('phpagi.php');
require_once("mysql_connect.php");
$script = 'get_parking_lot.php';
$verbosity = True;
error_reporting(E_ALL);
// Create MySQL connection
$mysqli = connectToDatabase();

# create new Agi
$AGI = new AGI();
if (!$AGI) {
$AGI->verbose("something went wrong");
        exit(1);}
$AGI->verbose("$script starting up");

if ($mysqli->connect_errno) {
    fwrite($stderr, "Failed to connect to MySQL: " . $mysqli->connect_error . "\n");
    exit(1);}
$AGI->verbose("MySQL connection Up");

// set parameters
$Tenant = $argv[1];
$park_exten = $argv[2];

$query = "SELECT parking_lot_name, extens_using FROM parking_details";# where cust_id='$Tenant'";
$AGI->verbose($query);
$result = $mysqli->query($query);

    while ($fieldinfo = $result->fetch_assoc()) {
    $lot_name = $fieldinfo["parking_lot_name"];
    $exten_list = $fieldinfo["extens_using"];

    $AGI->verbose("PARKING LOT NAME IS $lot_name");
    $AGI->verbose("EXTEN LIST IS $exten_list");
        $exten_list_ary  =       explode("-", $exten_list);
        $len_exten_list   =       count($exten_list_ary);
        for($i=0;$i<$len_exten_list;$i++)
        {
                if ($verbosity){$AGI->verbose("CURRENT EXTEN IS $exten_list_ary[$i]");}
                if ($exten_list_ary[$i]==$park_exten)
                        {
                        if ($verbosity){$AGI->verbose("EXTEN $exten_list_ary[$i] MATCHED");}
                        goto set_var;
                        }
                else{
                if ($verbosity){$AGI->verbose("EXTEN $exten_list_ary[$i] NOT MATCHED WITH $park_exten");}
                continue;
                }
         }

  }
$result -> free_result();
$mysqli -> close();

    # set return variable
set_var:
    $AGI->set_variable("PARKING_LOT", $lot_name);
?>

