#!/usr/bin/env /bin/php

<?php
require('phpagi.php');
//require('include/phpagi.php');
error_reporting(E_ALL);

//$db_ip = "127.0.0.1";
$db_ip = "localhost";
$db_user = "vitel_user";
$db_port = "3306";
$db_pass = "vitel_pbx123";

// Create MySQL connection
$mysqli = new mysqli($db_ip, $db_user, $db_pass, "asterisk");
if ($mysqli->connect_errno) {
    fwrite($stderr, "Failed to connect to MySQL: " . $mysqli->connect_error . "\n");
    exit(1);
}
# create new Agi
$AGI = new AGI();

if (!$AGI) {
        // something went wrong
$AGI->verbose("something went wrong");
        exit(1);
}
$AGI->verbose("MySQL connection Up");
$AGI->verbose("script starting up");

    $Tenant = $argv[1];
    $ringgroup = $argv[2];

$query = "SELECT call_recording from ringgroups where grp_exten='$ringgroup'  and cust_id='$Tenant'";
$result = $mysqli->query($query);
$fieldinfo = $result->fetch_assoc();
$caller_recording = $fieldinfo["call_recording"];

  $AGI->verbose("======================================");
  $AGI->verbose("CALL RECORDING FOR RINGGROUP $ringgroup WAS SET TO $caller_recording");
  $AGI->verbose("======================================");
 
//  CALL RECORDING OPTIONS

    $AGI->set_variable("__REC_OPT", $caller_recording);
?> 
