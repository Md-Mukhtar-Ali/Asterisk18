#!/usr/bin/env /bin/php

<?php
error_reporting(E_ALL);
require('modules.php');
require('phpagi.php');
require_once("mysql_connect.php");
$script_name = 'get_scheduler_timings.php';

// Create MYSQL Connection
$mysqli = connectToDatabase();
if (!$mysqli) {
  die("Connection failed: " . mysqli_connect_error());
}

// AGI_CMNT
 $AGI = new AGI();

if (!$AGI) {
        exit(1);
}
    $AGI->verbose("MySQL DATABASE CONNECTED SUCCESSFULLY");
    $scheduler_id   =   $argv[1];
        $AGI->verbose("SCHEDULER ID IS $scheduler_id");
    $customer_id    =   $argv[2];
        $AGI->verbose("CUSTOMER ID IS $customer_id");

//      $timegroup_id = 1;
//      $customer_id = 10001;

// Query to retrieve the saved schedules from the database

$query1 = "SELECT matched_dest, matched_dest_value, non_matched_dest, non_matched_dest_value,timegroup_id FROM scheduler_options WHERE scheduler_id='$scheduler_id'";# and cust_id='$customer_id'";
        $result1 = $mysqli->query($query1);
        if ($row1 = $result1->fetch_assoc()){
        $matched_app_dest       =       $row1['matched_dest'];
        $matched_app_value      =       $row1['matched_dest_value'];
        $non_matched_app_dest   =       $row1['non_matched_dest'];
        $non_matched_app_value  =       $row1['non_matched_dest_value'];
        $timegroup_id           =       $row1['timegroup_id'];

        $AGI->set_variable("__TRUE_DEST", $matched_app_dest);
        $AGI->set_variable("__TRUE_DEST_VALUE", $matched_app_value);
        $AGI->set_variable("__FAIL_DEST", $non_matched_app_dest);
        $AGI->set_variable("__FAIL_DEST_VALUE", $non_matched_app_value);
        }

$time = time_group($mysqli, $AGI, $timegroup_id, $customer_id);
if ($time == True){
	$AGI->exec('Gosub', 'scheduler,s,TRUE');
}elseif($time == False){
	$AGI->exec('Gosub', 'scheduler,s,NON_MATCH');
}
$result -> free_result();
$result1->free_result();

//}
$mysqli -> close();
?>

