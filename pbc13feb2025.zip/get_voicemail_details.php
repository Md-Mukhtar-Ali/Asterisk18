#!/usr/bin/env /bin/php

<?php
require('phpagi.php');
//require('include/phpagi.php');
error_reporting(E_ALL);

//$db_ip = "127.0.0.1";
$db_ip = "localhost";
$db_user = "vitel_user";
$db_port = "3306";
$db_pass = "vitel_pbx123";

// Create MySQL connection
$mysqli = new mysqli($db_ip, $db_user, $db_pass, "asterisk");
if ($mysqli->connect_errno) {
    fwrite($stderr, "Failed to connect to MySQL: " . $mysqli->connect_error . "\n");
    exit(1);
}
# create new Agi
$AGI = new AGI();

if (!$AGI) {
        // something went wrong
$AGI->verbose("something went wrong");
        exit(1);
}
$AGI->verbose("MySQL connection Up");
$AGI->verbose("script starting up");

    // set parameters
    $Tenant = $argv[1];
    $Exten  = $argv[2];
//$AGI->verbose("call for \"$Tenant$Exten\"");
$AGI->verbose("call for \"$Exten\"");

//  Check Call Forward Status and Fetch Forward Number data from a MySQL table

$query = "SELECT context, fullname, require_pwd_for_self,email FROM voicemail where mailbox='$Exten'";# and cust_id='$Tenant'";
if ($result = $mysqli -> query($query)) {
    
    while ($fieldinfo = $result -> fetch_assoc()) {
	    $VM_context		=	$fieldinfo["context"];
	    if($VM_context==""){ $VM_context="default"; }
    $VM_fullname        =       $fieldinfo["fullname"];
    $VM_req_passwd	=	$fieldinfo["require_pwd_for_self"];
    $Email              =       $fieldinfo["email"];
    $AGI->verbose("VOICEMAIL CONTEXT IS $VM_context");
    $AGI->verbose("CALLEE NAME IS $VM_fullname");
    $AGI->verbose("REQUIRE PASSWORD TO CHECK VM FOR EXTEN $Exten IS SET TO $VM_req_passwd");
  }
  $result -> free_result();
}

$mysqli -> close();    
    # set return variable
    $AGI->set_variable("__VM_CONTEXT", $VM_context);
    $AGI->set_variable("__FULL_NAME", $VM_fullname);
    $AGI->set_variable("__VM_REQ_PWD", $VM_req_passwd);
    $AGI->set_variable("__EMAIL", $Email);

?>
