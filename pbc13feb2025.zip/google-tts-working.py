#!/usr/bin/env python
import sys
import os
import subprocess
import base64
import requests
from asterisk.agi import *
import time
import wave
import uuid
# Set API key explicitly in the script
os.environ['GOOGLE_API_KEY'] = 'AIzaSyCcRr44-QmxxcF-37lEo9OdfRIYJeuJ5sc'

# Function to generate TTS using Google Cloud API with an API key
def generate_tts_google(api_key, text, output_file):
    url = "https://texttospeech.googleapis.com/v1/text:synthesize"

    headers = {
        "Content-Type": "application/json",
    }

    data = {
        "input": {
            "text": text
        },
        "voice": {
            "languageCode": "en-IN",
            "name": "en-IN-Journey-F"
        },
        "audioConfig": {
            "audioEncoding": "LINEAR16",  # Ensure we are getting LINEAR16 encoding (WAV format)
            "sampleRateHertz": 8000
        }
    }

    response = requests.post(url, headers=headers, params={'key': api_key}, json=data)

    if response.status_code == 200:
        audio_content = response.json().get("audioContent")
        if not audio_content:
            print('VERBOSE "Error: Empty audioContent" 1')
            sys.exit(1)
        audio_data = base64.b64decode(audio_content)
        with open(output_file, "wb") as out:
            out.write(audio_data)
        print(f'VERBOSE "Google TTS generated {output_file}" 1')
    else:
        print(f"VERBOSE \"Error generating TTS: {response.text}\" 1")
        sys.exit(1)

# Function to stream audio in AGI
def stream_audio(agi_file):
    print(f'STREAM FILE {agi_file} ""')
    #agi.stream_file(agi_file)
    sys.stdout.flush()

def get_audio_duration(file_path):
    with wave.open(file_path, 'rb') as audio_file:
        frames = audio_file.getnframes()
        rate = audio_file.getframerate()
        duration = frames / float(rate)
    return duration


# Main script
def main():
    agi = AGI()
    if len(sys.argv) < 2:
        agi.verbose("Error: No text input provided", 1)
        sys.exit(1)

    tts_text =sys.argv[1] 
    agi.verbose(f"TTS Input : {tts_text}", 1)
    print(f'VERBOSE "TTS Input: {tts_text}" 1')
    # Define file paths
    #audio_file = "/var/lib/asterisk/sounds/textToSpeech/test123.wav"
    unique_filename = f"{time.strftime('%Y%m%d%H%M%S')}_{uuid.uuid4().hex}"
    audio_file = f"/var/lib/asterisk/sounds/textToSpeech/{unique_filename}.wav"
    api_key = os.getenv("GOOGLE_API_KEY")
    if not api_key:
        print("VERBOSE \"Error: No Google Cloud API key found.\" 1")
        sys.exit(1)

    try:
        generate_tts_google(api_key, tts_text, audio_file)
    except Exception as e:
        print(f"VERBOSE \"Error generating TTS After function called: {e}\" 1")
        sys.exit(1)
    audio_duration = get_audio_duration(audio_file)
    # Stream the file and wait for the duration of the file
    agi.set_variable("AUDIO",unique_filename)
    agi.verbose(f"Duration========={audio_duration}")
    agi.verbose(f"Generated audio file: {audio_file}", 1)
    #agi.stream_file(f"textToSpeech/{unique_filename}")
    #time.sleep(audio_duration)
    #time.sleep(10) 

if __name__ == "__main__":
    main()
