#!/usr/bin/env /bin/php
<?php
require('phpagi.php');
require('modules.php');
error_reporting(E_ALL);
$verbosity = True;
$script_name = 'ivr_options.php';
//$db_ip = "127.0.0.1";
$db_ip = "localhost";
$db_user = "vitel_user";
$db_port = "3306";
$db_pass = "vitel_pbx123";

// DECLARING LOCAL VARIABLES
$moh_class='default';


// Create MySQL connection
$mysqli = new mysqli($db_ip, $db_user, $db_pass, "asterisk");
if ($mysqli->connect_errno) {
    fwrite($stderr, "Failed to connect to MySQL: " . $mysqli->connect_error . "\n");
    exit(1);
}
# create new Agi
$AGI = new AGI();

if (!$AGI) {
        // something went wrong
        exit(1);
}
$AGI->verbose("MySQL connection Up");
$AGI->verbose("script starting up");

    // set parameters
    $ivr_id 	= $argv[1];
    $ivr_sel	= $argv[2];

$AGI->set_variable("__IVRS_ID", $ivr_id);
$AGI->verbose("call landed on IVR ID \"$ivr_id\" and selection is \"$ivr_sel \"\n");

//  Check Call Forward Status and Fetch Forward Number data from a MySQL table

$query = "SELECT *  FROM ivr_entries where ivr_id='$ivr_id' and selection='$ivr_sel'";
//if ($result = $mysqli -> query($query)) {
$result = $mysqli -> query($query);
  // Get field information for all fields
    //$AGI->verbose("RESULT IS $result");

    if ($result->num_rows == 0) {

	$AGI->verbose("INVALID INPUT MODE");
	//$AGI->exec('Gosub', 'ivr-menu,i,1');
	$AGI->exec('Gosub', 'ivr-menu,s,dd-check');
    }else{
	
    $row = $result->fetch_assoc() ;
    //$AGI->verbose("Result in loop $result");

	$ivr_selection		=	$row["selection"];
	$AGI->verbose("selection is $ivr_selection");

	$application_dest	=	$row["dest"];
	$AGI->verbose("application is $application_dest");

	$app_dest_value		=	$row["dest_value"];
	$AGI->verbose("app value is $app_dest_value");

	$ivr_return		=	$row["ivr_ret"];
	$AGI->verbose($ivr_return);

	$customer_id    	=	$row["cust_id"];
	$AGI->verbose("CUSTOMER ID IS $customer_id");
    # set return variable

	//switch($result->dest)
	switch($application_dest)
	{
// QUEUE START
	case 'Queue':
        $AGI->verbose("queue(mysqli, AGI, $moh_class, $customer_id, $app_dest_value)");
        queue($mysqli, $AGI, $moh_class, $customer_id, $app_dest_value);

 	break;
// QUEUE END
	
// EXTENSIONS DIAL START
	case 'Extension':
        $AGI->verbose("Extension Dial Mode");
        $AGI->set_variable("__DIRECT_EXTEN", $app_dest_value);
        $AGI->set_variable("__CUST_ID", $customer_id);
        $AGI->exec('Gosub', 'App-Extension-Dial,s,1');
        break;

// EXTENSION DIAL END

// DIRECTORY START
        case 'Directory':
        $AGI->verbose("directory(mysqli, AGI, $app_dest_value, $customer_id, $call_source, $ivr_id");
        directory($mysqli, $AGI, $app_dest_value, $customer_id, $call_source, $ivr_id);

        break;
// DIRECTORY END

// ANNOUNCEMENT START
        case 'Announce':
        $AGI->verbose("Announcement Mode");
	
	$query2 = "SELECT *  FROM announcement where announcement_id='$app_dest_value'";	

	if ($result2 = $mysqli->query($query2))
        {
        // Get field information for all fields
       // $AGI->verbose($result2);

        while ($row2 = $result2->fetch_assoc())
                {
        $customer_id	=       $row2["cust_id"];
        $audio_file_id	=       $row2["audio_file_id"];
        $skip_playback	=       $row2["allow_skip"];
        $return_to_ivr	=       $row2["return_ivr"];
        $disable_answer	=	$row2["noanswer"];
        $repeat_key	=	$row2["key_press_to_repeat"];

	$post_dest              =       $row2["post_dest"];
        $AGI->verbose("FINAL DESTINATION IS $post_dest");

        $post_dest_value        =       $row2["post_dest_value"];
        $AGI->verbose("FINAL DESTINATION VALUE IS $post_dest_value");

        $AGI->verbose("Audio File ID is $audio_file_id");
        $AGI->set_variable("SKIP_PLAYBACK", $skip_playback);
        $AGI->set_variable("CUST_ID", $customer_id);
        $AGI->set_variable("IVR_RET", $return_to_ivr);
        $AGI->verbose("IVR RETURN is $return_to_ivr");
        $AGI->set_variable("IVRS_ID", $ivr_id);
        $AGI->set_variable("DISABLE_ANS", $disable_answer);
        $AGI->set_variable("KEY_REPEAT", $repeat_key);
        

	$query1 = "SELECT File_Location  FROM pss_audio_files where File_id='$audio_file_id'";
	if ($result1 = $mysqli->query($query1)) 
	{
  	// Get field information for all fields
    	//$AGI->verbose($result1);

    	while ($row1 = $result1->fetch_assoc()) 
		{
	$aud_file_loc 	=	$row1["File_Location"];
    	$AGI->verbose("Audio File Location is $aud_file_loc");
        $AGI->set_variable("AUD_FILE_LOC", $aud_file_loc);
	$AGI->set_variable("__IVRS_ID", $ivr_id);
    	$AGI->verbose("IVRS ID set to  $ivr_id");
      //$AGI->exec('Gosub', 'announcement,s,1(IVRS_ID)');
       $AGI->set_variable("POST_DEST",$post_dest);
       $AGI->set_variable("DEST_VALUE",$post_dest_value);
       $AGI->set_variable("__CALL_SRC", $call_source);
 
        $AGI->exec('Gosub', 'announcement,s,1');
		}
	}else{
    	$AGI->verbose("File path is missing");
	}
		}
	}       
 break;
// ANOUNCEMENT END

// IVR START
	case 'IVR':
	$AGI->verbose("IVR TRASFER MODE");
        $AGI->set_variable("IVRS_ID", $app_dest_value);
	$AGI->exec('Gosub', 'ivr-menu,s,1');
	break;
// IVR END 

// TERMINATE-CALL START
	case 'Terminate-call':
	switch($app_dest_value) {
	case 'Busy':
	$AGI->verbose("BUSY  MODE");
	$AGI->exec('busy');
	break;
	case 'Congestion':
	$AGI->verbose("CONGESTION MODE");
	$AGI->exec('congestion');	
	break;
	default:
	$AGI->verbose("DEFAUL HANGUP MODE");
	$AGI->exec('Playback','en/goodbye');
	$AGI->exec('hangup');
	}
	break;
// TERMINATE-CALL END

// VOICEMAIL START
	case 'Voicemail':
 	$AGI->verbose("VoiceMail Mode");
        $query3 = "SELECT context,mailbox  FROM voicemail where mailbox='$app_dest_value'";
        if ($result3 = $mysqli->query($query3))
        {
        // Get field information for all fields
        //$AGI->verbose($result3);
	if ($result3->num_rows == 0) {
	$AGI->verbose("NO VALID CONTEXT FOUND IN DB FOR THE ENTERED DIRECT EXTENSION");
        $AGI->exec('Gosub', 'INVALID_DIRECT-DIAL,s,1');
	    }

        while ($row3 = $result3->fetch_assoc())
                {
        $vm_context	  =       $row3["context"];
        $vm_exten	  =       $row3["mailbox"];
        $AGI->verbose("VoiceMail Context is $vm_context");
        $AGI->verbose("VoiceMail Extension is $vm_exten");
        $AGI->set_variable("VM_CONTEXT", $vm_context);
        $AGI->set_variable("VM_EXTEN", $vm_exten);
        $AGI->set_variable("IVR_RET", $ivr_return);
        $AGI->exec('Gosub', "voicemail,$vm_exten,1");
        //$AGI->exec('Gosub', 'ivr-menu,s,skip');
		}
	}else{
        $AGI->verbose("NO VALID CONTEXT FOUND IN DB FOR THE ENTERED DIRECT EXTENSION");
        $AGI->exec('Gosub', 'INVALID_DIRECT-DIAL,s,1');
//      $AGI->gosub('INVALID_DIRECT-DIAL', 's', '1','');
        }

	break;

// VOICEMAIL END

// CONFERENCE START
        case 'Conference':
        if ($verbosity){$AGI->verbose("ENTERING CONFERENCE MODE");}
        conference($mysqli, $AGI, $app_dest_value, $customer_id);
/*        $AGI->answer();
        $AGI->verbose("ENTERING CONFERENCE MODE");
        $query5 = "SELECT * FROM conf_bridge_entries where conf_no='$app_dest_value' and cust_id='$customer_id'";
        if ($result5 = $mysqli->query($query5))
        {
        // Get field information for all fields
        //$AGI->verbose($result5);

        while ($row5 = $result5->fetch_assoc())
                {
        //$conf_start     =       $row5["starttime"];
        //$conf_end       =       $row5["endtime"];
        $guest_menu     =       $row5["user_opts"];
        $admin_menu     =       $row5["admin_opts"];
        $admin_pin      =       $row5["admin_pin"];
        $guest_pin      =       $row5["guest_pin"];
        $bridge_name    =       $row5["bridge_profile"];

        $AGI->verbose("$guest_menu");
        $AGI->verbose("$admin_menu");
        $AGI->verbose("$admin_pin");
        $AGI->verbose("$guest_pin");
        $AGI->verbose("$bridge_name");

        $len_admin_pin = strlen($admin_pin);
        $len_guest_pin = strlen($guest_pin);

        $AGI->verbose("Admin PIN length is $len_admin_pin");
        $AGI->verbose("Guest PIN length is $len_guest_pin");
        //if strlen($admin_pin) > strlen($guest_pin){
        $max_len_pin = max($len_admin_pin, $len_guest_pin);
        //}

/// GET CONF PIN FROM USER AND IDENTIFY IF "GUEST" OR "ADMIN"
        $invalid_input = True;
        $invalid_attempts = 0;
        while ($invalid_input){
        $user_input = $AGI->get_data('en/conf-getpin', 5 , $max_len_pin);
/// 	EXTRACT DATA FROM ARRAY
//      foreach ($user_input as $x => $xassoc) {
//        $AGI->verbose("USER ENTERED PIN IS $x and $xassoc");
//        }
        $user_pin = $user_input['result'];
        $AGI->verbose("USER ENTERED PIN IS $user_pin");

        if ($user_pin == $admin_pin){
                $invalid_input = False;
                $AGI->set_variable("CONF_NO", $app_dest_value);
                $AGI->set_variable("BRIDGE_NAME", $bridge_name);
                $AGI->set_variable("USER_TYPE", "admin_user");
                $AGI->set_variable("USER_MENU", $admin_menu);
                $AGI->set_variable("CALL_SRC", "conference");

                $AGI->exec('Gosub', 'conference-dial,s,1');
        }elseif($user_pin == $guest_pin){
                $invalid_input = False;
                $AGI->set_variable("CONF_NO", $app_dest_value);
                $AGI->set_variable("BRIDGE_NAME", $bridge_name);
                $AGI->set_variable("USER_TYPE", "guest_user");
                $AGI->set_variable("USER_MENU", $admin_menu);
                $AGI->set_variable("CALL_SRC", "conference");

                $AGI->exec('Gosub', 'conference-dial,s,1');

        }else{
        $invalid_attempts++;
        if ($invalid_attempts == 3){
                $invalid_input = False;
                $AGI->stream_file('en/confbridge-pin-bad');
                $AGI->set_variable("CALL_SRC", $call_source);
                $AGI->exec('Gosub', 'terminate-call,s,1');
                }
        else{
                $AGI->stream_file('en/conf-invalidpin');
                continue;
        }
//      continue;
        }
        }
// END OF GETTING USER PIN
                }
        }
        $AGI->verbose("CONFERENCE MODE COMPLETED");
*/
        break;

// CONFERENCE END



// RINGGROUP START
        case 'RingGroup':
	ringgroup($mysqli, $AGI, $app_dest_value, $customer_id);
        break;
/*	$query6 = "SELECT *  FROM ringgroups where grp_exten='$app_dest_value' and cust_id='$customer_id'";
        $AGI->verbose("ENTERED RINGGROUP MENU");
        //if ($result6 = $mysqli->query($query6))
        $result6 = $mysqli->query($query6);
        $AGI->verbose("ENTERED RINGGROUP RESULT IS $result6->num_rows");
        if ($result6->num_rows > 0)
        {
        // Get RING GROUP DATA
        $AGI->verbose("RESULT OF SELECT QUEREY RING GROUP DATA IS $result6");
        $row6 = $result6->fetch_assoc();
        $AGI->verbose($result6);
        $grp_strategy   =       $row6["strategy"];
        $grp_list       =       $row6["grplist"];
        $moh_class      =       $row6["musiconhold"];
        $prompt_id      =       $row6["prompt_id"];
	$cid_name_prefix        =       $row6["cid_name_prefix"];
        $grp_ringtime   =       $row6["grp_ringtime"];
        $dest_check     =       $row6["enable_dest"];
	$post_dest      =       $row6["postdest"];
        $post_dest_value=       $row6["postdest_value"];
        $admin_opts     =       $row6["adminopts"];
        $skip_wn_busy   =       $row6["skip_busy"];
        $grp_call_record=       $row6["recording"];
        $call_recording_option=$row6["call_recording"];


        $AGI->set_variable("FINAL_DEST_CHECK", $dest_check);
        $AGI->set_variable("CID_NAME_PREFIX",$cid_name_prefix);
        $AGI->set_variable("MOH_CLASS", $moh_class);
        $AGI->set_variable("SKIPBUSY_AGENT", $skip_wn_busy);
        $AGI->set_variable("RINGGROUP_ID", $app_dest_value);
        $AGI->set_variable("REC_OPT",$call_recording_option);


        $AGI->verbose("FINAL DESTINATION CHECK IS $dest_check");
        $AGI->verbose("EXT GRP LIST IS $grp_list");
	$AGI->verbose("CID\(NAME/) PREFIX FOR RING GROUP $app_dest_value SET TO $cid_name_prefix");
        $grp_exten_ary  =       explode("-", $grp_list);
        $len_grp_list   =       count($grp_exten_ary);
        $AGI->verbose("ARRAY LENGTH IS $len_grp_list");
//		ADDING MOH & SKIPBUSY_AGENT - START
        $AGI->verbose("SKIP BUSY AGENT STATUS IS SET TO $skip_wn_busy");
//		ADDING MOH & SKIPBUSY_AGENT - END

//	GETTING AUDIO PROMPT DETAILS - START
        $audio_query = "SELECT File_Location  FROM pss_audio_files where File_id='$prompt_id'";
        $audio_result = $mysqli->query($audio_query);
        //$AGI->verbose($audio_result);
        if ($audio_result->num_rows > 0)
        {
        // Get field information for all fields
        $prompt_row = $audio_result->fetch_assoc();
        $aud_file_loc           =       $prompt_row["File_Location"];
        $AGI->verbose("AUDIO PROMPT IS $aud_file_loc");
        $AGI->set_variable("AUD_FILE_LOC", $aud_file_loc);

        }else{
		$AGI->set_variable("AUD_FILE_LOC", "INVALID");		
        $AGI->verbose("PROMPT FILE LOCATION NOT FOUND");
        }
//	GETTING AUDIO PROMPT DETAILS - END

        if ($len_grp_list == 0){
        $AGI->verbose("RING GROUP LIST IS EMPTY");
        }else{
        $AGI->verbose("CHECKING GROUP STRATEGY");

        $dial_string = '';
        switch($grp_strategy){

        case 'ringall':

        $AGI->verbose("RING GROUP STRATEGY IS $grp_strategy");
//
//        for($i=0;$i<$len_grp_list;$i++)
//	  {
//     $a1=$grp_exten_ary[$i];
//      $AGI->verbose("CURRENT WORKING ON EXTENSION NUMBER $a1\n");
//      $extstate_result = is_ext_avail($a1);
//      $AGI->verbose("EXTENSION STATUS IS $extstate_result\n");
//      exit();
//      $dial_string = $dial_string . $grp_exten_ary[$i];
//       $AGI->verbose("DIAL STRING => '$dial_string'");
//        if (isset($grp_exten_ary[$i+1])){
//                $dial_string = $dial_string . "&PJSIP/";
//                $AGI->verbose("DIAL STRING - $dial_string");
//                }
//          }
//
	$AGI->set_variable("POST_DEST", $post_dest);
	$AGI->set_variable("DEST_VALUE", $post_dest_value);
        $AGI->set_variable("GRP_RING_TIME", $grp_ringtime);
          
        $AGI->set_variable("GRP_DIAL_STRING", $grp_list);
        $AGI->set_variable("CALL_SRC", $call_source);
        $AGI->exec('Gosub', 'grp-dial-ringall,s,1');
        break;

        case 'hunt':
        $AGI->verbose("RING GROUP STRATEGY IS $grp_strategy");
        $AGI->set_variable("HUNT_COUNT",$len_grp_list);
        $AGI->set_variable("EXTEN_STRING",$grp_list);
        $myhuntmember='';
        $HUNTMEMBER ='HUNTMEMBER';

//	LOOPING THROUGH GRP LIST AND APPENDING COUNT AFTER HUNTMEMBER NAME - START
        for($i=0;$i<$len_grp_list;$i++){
        $myhuntmember = $HUNTMEMBER . $i;
        $AGI->verbose("CURRENT HUNT MEMEBER IS $myhuntmember  $grp_exten_ary[$i]");
        $AGI->set_variable($myhuntmember,$grp_exten_ary[$i]);
                }
//	LOOPING THROUGH GRP LIST AND APPENDING COUNT AFTER HUNTMEMBER NAME - END

	$AGI->set_variable("POST_DEST", $post_dest);
	$AGI->set_variable("DEST_VALUE", $post_dest_value);
        $AGI->set_variable("GRP_RING_TIME", $grp_ringtime);
        $AGI->set_variable("CALL_SRC", $call_source);
 	$AGI->exec('Gosub', 'grp-dial-hunt,s,1');

        break;

        default:
        $AGI->verbose("INVALID RINGING STRATEGY");
                }
        }
}else{
        $AGI->verbose("NO DATA FOUND FOR THE GIVEN RINGGROUP EXTENSION");
}
	break;
*/
// RINGGROUP END

// TIME CONDITION - SCHEDULER START
        case 'TimeCondition':

        $AGI->verbose("TIME GROUPS & CONDITION BASED SCHEDULER MODULE");
        $AGI->set_variable("TIME_CONDITION", $app_dest_value);
//        $AGI->set_variable("CUST_ID", $customer_id);
        $AGI->exec('Gosub', 'time-condition,s,1');
        break;
// TIME CONDITION - SCHEDULER END

/*
// TIME GROUPS - SCHEDULER START
	case 'TimeGroup':

	$AGI->verbose("TIME GROUPS & CONDITION BASED SCHEDULER MODULE");
	$AGI->set_variable("TIME_GROUP", $app_dest_value);
//        $AGI->set_variable("CUST_ID", $customer_id);
	$AGI->exec('Gosub', 'time-group,s,1');
	break;
// TIME GROUPS - SCHEDULER END
*/

// PAGING START
        case 'Paging':
        paging($mysqli, $AGI, $app_dest_value, $customer_id);
        break;

// PAGING END


	default:	
	$AGI->verbose("Default Selection Mode ");
	}
  //}
}

	$mysqli -> close();    
    	$AGI->set_variable("IVR_RETN", $ivr_return);
        $AGI->verbose("IVR RETURN STATUS SET TO $ivr_return");
  	$result -> free_result();
?>
