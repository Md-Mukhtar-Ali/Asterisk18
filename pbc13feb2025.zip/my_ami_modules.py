#!/var/lib/asterisk/agi-bin/pyst_env/bin/python
import asterisk.manager
import sys
import re
import time
import MySQLdb

class AMI_METHODS:
	def __init__(self):
		# DB CREDENTIALS
		self.db = MySQLdb.connect("localhost", "vitel_user", "vitel_pbx123", "asterisk")

		# Asterisk Manager Interface (AMI) credentials
		self.ami_host = 'localhost'
		self.ami_port = 5038
		self.ami_username = 'viteluser'
		self.ami_password = 'vitelpbx123'

		self.ami = asterisk.manager.Manager()
		self.ami.connect(self.ami_host, self.ami_port)

	def handle_shutdown(self, event):
		'''Closes the AMI connection when a Shutdown Event is obtained'''
		# print("Received shutdown event")
		self.ami.close()

	def update_talker_status(self, channel, isTalking, party_num, party_name, party_unq_id):
		pass
		#print(channel)

	def handle_event(self, event):
		''' Handles Any AMI Event Passed Here '''
		# print("Received event: " + event.name)
		if event.name == 'DeviceStateChange':
			device = event.get_header('Device')
			match = re.match(r'\s*PJSIP/(\S+)', device)
			if match:
				exten = match.group(1)
				status_change = event.get_header('State')
				self.update_exten_status(exten, status_change)

		if event.name == 'ChannelTalkingStart':
			channel = event.get_header('Channel')
			party_num = event.get_header('CallerIDNum')
			party_name = event.get_header('CallerIDName')
			party_unq_id = event.get_header('Uniqueid')
			self.update_talker_status(channel,'yes', party_num, party_name, party_unq_id)

	def update_exten_status(self, exten, status):
		''' Updates Extension status for existing extension/Inserts new record of Extension and status in the table `exten_live_status`'''
		select_query = "select status from exten_live_status where extension='" + exten + "'"
		update_query = "update exten_live_status set status='" + status + "' where extension = '" + exten + "'"
		insert_query = "insert into exten_live_status (extension, status) values ('" + exten + "', '" + status + "')"
		cursor = self.db.cursor()
		cursor.execute(select_query)

		res = cursor.fetchone()
		res_type = str(type(res)).split("'")[1]
		if res_type == "NoneType":
			cursor.execute(insert_query)
			self.db.commit()
			cursor.close()
		else:
			cursor.execute(update_query)
			self.db.commit()
			cursor.close()

	def login_ami(self):
		# print("hostname: " + self.ami_host)
		self.ami.login(self.ami_username, self.ami_password)

	def event_callback(self, event):
		print("Received Event: " + event.name)
		print("Event Data: " + event)

	def handle_dev_state_update_event(self, event):
		''' This function is used to handle `DeviceStateChange` Events and the same status of the device is updated/inserted in the table `exten_live_status`'''
		if event.name == 'DeviceStateChange':
			device = event.get_header('Device')
			match = re.match(r'\s*PJSIP/(\S+)', device)
			if match:
				exten = match.group(1)
				status_change = event.get_header('State')
				self.update_exten_status(exten, status_change)

	def exten_live_state_update(self):
		try:
			# Connect to AMI
			self.login_ami()

			self.ami.register_event('Shutdown', self.handle_shutdown)  # shutdown
			self.ami.register_event('DeviceStateChange', self.handle_dev_state_update_event)  # device state changes
			time.sleep(59)
			# get a status report
			response = self.ami.status()
			self.ami.close()
		except asterisk.manager.ManagerSocketException as e:
			print("Error connecting to the manager: " + e.strerror)
			self.ami.close()
			sys.exit(1)
		except asterisk.manager.ManagerAuthException as e:
			print("Error logging into the manager: " + e.strerror)
			self.ami.close()
			sys.exit(1)
		except asterisk.manager.ManagerException as e:
			print("Error: " + e.strerror)
			self.ami.close()
			sys.exit(1)

if __name__ == "__main__":
	ami_methods = AMI_METHODS()
	ami_methods.exten_live_state_update()


