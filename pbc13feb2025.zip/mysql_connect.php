#!/usr/bin/env /bin/php
<?php

$script_name = 'MySQL_CONNECT';
#echo $script_name." IS RUNNING \n";
function connectToDatabase()
{
	//$db_ip = "127.0.0.1";
	$db_ip = "localhost";
	$db_user = "vitel_user";
	$db_port = "3306";
	$db_pass = "vitel_pbx123";
	$db_name = "asterisk";

    // Create a new MySQLi object
    $mysqli = new mysqli($db_ip, $db_user, $db_pass, $db_name);

    // Check if the connection was successful
    if ($mysqli->connect_errno) {
        die("Failed to connect to MySQL: " . $mysqli->connect_error);
	exit(1);
    	}	
	#echo "\nMySQL connection Up \n";

    // Set the character set to UTF-8 (optional)
    //$mysqli->set_charset("utf8");

    // Return the database connection object
    return $mysqli;
}
?>
