#!/usr/bin/env /bin/php
<?php
require('phpagi.php');
require('modules.php');
error_reporting(E_ALL);

$script_name = 'final_destination.php';
//$db_ip = "127.0.0.1";
$db_ip = "localhost";
$db_user = "vitel_user";
$db_port = "3306";
$db_pass = "vitel_pbx123";

// Create MySQL connection
$mysqli = new mysqli($db_ip, $db_user, $db_pass, "asterisk");
if ($mysqli->connect_errno) {
    fwrite($stderr, "Failed to connect to MySQL: " . $mysqli->connect_error . "\n");
    exit(1);
}
# create new Agi
$AGI = new AGI();

if (!$AGI) {
        // something went wrong
        exit(1);
}
	$AGI->verbose("MySQL connection Up");
	$AGI->verbose("script $script_name starting up");

    // set parameters
	$application_dest 	=	$argv[1];
	$app_dest_value		=	$argv[2];
	$customer_id		=	$argv[3];

	switch($application_dest)
	{
// QUEUE START
	case 'Queue':
        queue($mysqli, $AGI, $moh_class, $customer_id, $app_dest_value);
	break;
// QUEUE END
	
// EXTENSIONS DIAL START
	 case 'Extension':
        $AGI->verbose("Extension Dial Mode");
        $AGI->set_variable("DIRECT_EXTEN", $app_dest_value);
        $AGI->set_variable("CUST_ID", $customer_id);
        $AGI->exec('Gosub', 'App-Extension-Dial,s,1');
        break;

// EXTENSION DIAL END

// DIRECTORY START
        case 'Directory':
        directory($mysqli, $AGI, $app_dest_value, $customer_id, $call_source);

/*        $AGI->verbose("Directory Mode");
        $AGI->set_variable("REQ_VM_CNTX", $app_dest_value);
        $AGI->exec('Gosub', 'directory,s,1');
*/  
      break;
// DIRECTORY END

// ANNOUNCEMENT START
        case 'Announce':
        $AGI->verbose("Announcement Mode");
	
	$query2 = "SELECT *  FROM announcement where announcement_id='$app_dest_value'";	

	$result2 = $mysqli->query($query2);
	if ($result2->num_rows > 0)
        {
        $row2 = $result2->fetch_assoc();
                
        $customer_id	=       $row2["cust_id"];
        $audio_file_id	=       $row2["audio_file_id"];
        $skip_playback	=       $row2["allow_skip"];
        $return_to_ivr	=       $row2["return_ivr"];
        $disable_answer	=	$row2["noanswer"];
        $repeat_key	=	$row2["key_press_to_repeat"];

        $AGI->verbose("Audio File ID is $audio_file_id");
        $AGI->set_variable("SKIP_PLAYBACK", $skip_playback);
        $AGI->set_variable("CUST_ID", $customer_id);
        $AGI->set_variable("IVR_RET", $return_to_ivr);
        $AGI->verbose("IVR RETURN is $return_to_ivr");
        #$AGI->set_variable("IVRS_ID", $ivr_id);
        $AGI->set_variable("DISABLE_ANS", $disable_answer);
        $AGI->set_variable("KEY_REPEAT", $repeat_key);
        
  // GETTING POST DESTINATION DETAILS FOR SELECTED ANNOUNCEMENT
        $post_dest              =       $row2["post_dest"];
        $AGI->verbose("FINAL DESTINATION IS $post_dest");

        $post_dest_value        =       $row2["post_dest_value"];
        $AGI->verbose("FINAL DESTINATION VALUE IS $post_dest_value");

       $AGI->set_variable("POST_DEST",$post_dest);
       $AGI->set_variable("DEST_VALUE",$post_dest_value);

	$query1 = "SELECT File_Location  FROM pss_audio_files where File_id='$audio_file_id'";
	$result1 = $mysqli->query($query1);
    	//$AGI->verbose($result1);
	if ($result1->num_rows > 0) 
	{
    	$row1 = $result1->fetch_assoc(); 
	$aud_file_loc 		=	$row1["File_Location"];
    	$AGI->verbose("Audio File Location is $aud_file_loc");
        $AGI->set_variable("AUD_FILE_LOC", $aud_file_loc);
	#$AGI->set_variable("IVRS_ID", $ivr_id);
    	#$AGI->verbose("IVRS ID set to  $ivr_id");
      //$AGI->exec('Gosub', 'announcement,s,1(IVRS_ID)');
        $AGI->exec('Gosub', 'announcement,s,1');
		
	}else{
    	$AGI->verbose("File path is missing");
	}
		
	}else{
        $AGI->verbose("NO ENTRY FOR ANNOUNCEMENT IS FOUND");
        }
       
 break;
// ANOUNCEMENT END

// IVR START
	case 'IVR':
	$AGI->verbose("IVR TRASFER MODE");
        $AGI->set_variable("IVRS_ID", $app_dest_value);
	$AGI->exec('Gosub', 'ivr-menu,s,1');
	break;
// IVR END 

// TERMINATE-CALL START
	//case 'Terminate-call':
	case 'Hangup':
	switch($app_dest_value) {
	case 'Busy':
	$AGI->verbose("BUSY  MODE");
	$AGI->exec('busy');
	break;
	case 'Congestion':
	$AGI->verbose("CONGESTION MODE");
	$AGI->exec('congestion');	
	break;
	default:
	$AGI->verbose("DEFAUL HANGUP MODE");
	$AGI->exec('Playback','en/goodbye');
	$AGI->exec('hangup');
	}
	break;
// TERMINATE-CALL END

// VOICEMAIL START
	case 'Voicemail':
 	$AGI->verbose("VoiceMail Mode");
        $query3 = "SELECT context,mailbox  FROM voicemail where mailbox='$app_dest_value'";
        if ($result3 = $mysqli->query($query3))
        {
        // Get field information for all fields
        //$AGI->verbose($result3);

        while ($row3 = $result3->fetch_assoc())
                {
        $vm_context	  =       $row3["context"];
        $vm_exten	  =       $row3["mailbox"];
        $AGI->verbose("VoiceMail Context is $vm_context");
        $AGI->verbose("VoiceMail Extension is $vm_exten");
        $AGI->set_variable("VM_CONTEXT", $vm_context);
        $AGI->set_variable("VM_EXTEN", $vm_exten);
	$AGI->set_variable("IVR_RET", $ivr_return);
//	$AGI->exec('Gosub', 'voicemail,s,1');// old one
	$AGI->exec('Gosub', "voicemail,$vm_exten,1");
        //$AGI->exec('Gosub', 'ivr-menu,s,skip');
		}
	}
	break;

// VOICEMAIL END

// CONFERENCE START
        case 'Conference':
        if ($verbosity){$AGI->verbose("ENTERING CONFERENCE MODE");}
        conference($mysqli, $AGI, $app_dest_value, $customer_id);
        break;

// CONFERENCE END

// RINGGROUP START
        case 'RingGroup':
        ringgroup($mysqli, $AGI, $app_dest_value, $customer_id);
        break;
/*
        $query6 = "SELECT *  FROM ringgroups where grp_exten='$app_dest_value' and cust_id='$customer_id'";
        $AGI->verbose("ENTERED RINGGROUP MENU");
        //if ($result6 = $mysqli->query($query6))
        $result6 = $mysqli->query($query6);
        $AGI->verbose("ENTERED RINGGROUP RESULT IS $result6->num_rows");
        if ($result6->num_rows > 0)
        {
        // Get RING GROUP DATA
        $AGI->verbose("RESULT OF SELECT QUEREY RING GROUP DATA IS $result6");
        $row6 = $result6->fetch_assoc();
  //      $AGI->verbose($result6);
        $grp_strategy   =       $row6["strategy"];
        $grp_list       =       $row6["grplist"];
        $moh_class      =       $row6["musiconhold"];
        $prompt_id      =       $row6["prompt_id"];
        $cid_name_prefix        =       $row6["cid_name_prefix"];
        $grp_ringtime   =       $row6["grp_ringtime"];
        $dest_check     =       $row6["enable_dest"];
        $post_dest      =       $row6["postdest"];
        $post_dest_value=       $row6["postdest_value"];
        $admin_opts     =       $row6["adminopts"];
        $skip_wn_busy   =       $row6["skip_busy"];
        $grp_call_record =       $row6["recording"];
        $call_recording_option = $row6["call_recording"];


        $AGI->set_variable("FINAL_DEST_CHECK", $dest_check);
        $AGI->set_variable("CID_NAME_PREFIX",$cid_name_prefix);
        $AGI->set_variable("MOH_CLASS", $moh_class);
        $AGI->set_variable("SKIPBUSY_AGENT", $skip_wn_busy);
        $AGI->set_variable("RINGGROUP_ID", $app_dest_value);
        $AGI->set_variable("REC_OPT", $call_recording_option);

        $grp_exten_ary  =       explode("-", $grp_list);
        $len_grp_list   =       count($grp_exten_ary);

        $AGI->verbose("FINAL DESTINATION CHECK IS $dest_check");
        $AGI->verbose("EXTEN GRP LIST IS $grp_list");
        $AGI->verbose("ARRAY LENGTH IS $len_grp_list");
        $AGI->verbose("CID(NAME) PREFIX FOR RING GROUP $app_dest_value SET TO $cid_name_prefix");
        $AGI->verbose("SKIP BUSY AGENT STATUS IS SET TO $skip_wn_busy");
	$AGI->verbose("CALL RECORDING FOR RINGGROUP $app_dest_value WAS SET TO $call_recording_option");


//      GETTING AUDIO PROMPT DETAILS - START
        $audio_query = "SELECT File_Location  FROM pss_audio_files where File_id='$prompt_id'";
        $audio_result = $mysqli->query($audio_query);
        //$AGI->verbose($audio_result);
        if ($audio_result->num_rows > 0)
        {
        // Get field information for all fields
        $prompt_row = $audio_result->fetch_assoc();
        $aud_file_loc           =       $prompt_row["File_Location"];
        $AGI->verbose("AUDIO PROMPT IS $aud_file_loc");
        $AGI->set_variable("AUD_FILE_LOC", $aud_file_loc);

        }else{
                $AGI->set_variable("AUD_FILE_LOC", "INVALID");
        $AGI->verbose("PROMPT FILE LOCATION NOT FOUND");
        }
//      GETTING AUDIO PROMPT DETAILS - END

        if ($len_grp_list == 0){
        $AGI->verbose("RING GROUP LIST IS EMPTY");
        }else{
        $AGI->verbose("CHECKING GROUP STRATEGY");

        $dial_string = '';
        switch($grp_strategy){

        case 'ringall':

        $AGI->verbose("RING GROUP STRATEGY IS $grp_strategy");

//        for($i=0;$i<$len_grp_list;$i++)
//          {
///    $a1=$grp_exten_ary[$i];
///     $AGI->verbose("CURRENT WORKING ON EXTENSION NUMBER $a1\n");
///     $extstate_result = is_ext_avail($a1);
///     $AGI->verbose("EXTENSION STATUS IS $extstate_result\n");
///     exit();
//    $dial_string = $dial_string . $grp_exten_ary[$i];
//      $AGI->verbose("DIAL STRING => '$dial_string'");
//      if (isset($grp_exten_ary[$i+1])){
//              $dial_string = $dial_string . "&PJSIP/";
//              $AGI->verbose("DIAL STRING - $dial_string");
//              }
//        }
//
        $AGI->set_variable("POST_DEST", $post_dest);
        $AGI->set_variable("DEST_VALUE", $post_dest_value);
        $AGI->set_variable("GRP_RING_TIME", $grp_ringtime);

        $AGI->set_variable("GRP_DIAL_STRING", $grp_list);
        $AGI->set_variable("CALL_SRC", $call_source);
        $AGI->exec('Gosub', 'grp-dial-ringall,s,1');
        break;

        case 'hunt':
        $AGI->verbose("RING GROUP STRATEGY IS $grp_strategy");
        $AGI->set_variable("HUNT_COUNT",$len_grp_list);
        $AGI->set_variable("EXTEN_STRING",$grp_list);
        $myhuntmember='';
        $HUNTMEMBER ='HUNTMEMBER';
        for($i=0;$i<$len_grp_list;$i++){
        $myhuntmember = $HUNTMEMBER . $i;
        $AGI->verbose("CURRENT HUNT MEMEBER IS $myhuntmember  $grp_exten_ary[$i]");
        $AGI->set_variable($myhuntmember,$grp_exten_ary[$i]);
                }
        $AGI->set_variable("POST_DEST", $post_dest);
        $AGI->set_variable("DEST_VALUE", $post_dest_value);
        $AGI->set_variable("GRP_RING_TIME", $grp_ringtime);
        $AGI->set_variable("CALL_SRC", $call_source);
        $AGI->exec('Gosub', 'grp-dial-hunt,s,1');

        break;
        default:
        $AGI->verbose("INVALID RINGING STRATEGY");
                }
        }
}else{
        $AGI->verbose("NO DATA FOUND FOR THE GIVEN RINGGROUP EXTENSION");
}
        break;
*/

// RINGGROUP END
// TIME CONDITION - SCHEDULER START
        case 'TimeCondition':

        $AGI->verbose("TIME GROUPS & CONDITION BASED SCHEDULER MODULE");
        $AGI->set_variable("CALL_SRC", $call_source);
        $AGI->set_variable("TIME_CONDITION", $app_dest_value);
//        $AGI->set_variable("CUST_ID", $customer_id);
        $AGI->exec('Gosub', 'time-condition,s,1');
        break;
// TIME CONDITION - SCHEDULER END

// TIME GROUPS - SCHEDULER START
        case 'TimeGroup':

        $AGI->verbose("TIME GROUPS & CONDITION BASED SCHEDULER MODULE");
        $AGI->set_variable("TIME_GROUP", $app_dest_value);
//        $AGI->set_variable("CUST_ID", $customer_id);
        $AGI->exec('Gosub', 'time-group,s,1');
        break;
// TIME GROUPS - SCHEDULER END

// PAGING START
        case 'Paging':
        paging($mysqli, $AGI, $app_dest_value, $customer_id);
        break;

// PAGING END


	default:	
	$AGI->verbose("Default Selection Mode ");
	}
//  }
//}
  	$result -> free_result();

	$mysqli -> close();    
    	$AGI->set_variable("IVR_RETN", $ivr_return);

?>
