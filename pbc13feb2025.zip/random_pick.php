<?php
$input = array("Neo", "Morpheus", "Trinity", "Cypher", "Tank");
function pick_rand($input){
	$rand_key = array_rand($input, count($input));
	print ("Result Data Type:'");
	print (var_dump($rand_key)."'\n");
	print ("Printing Result:\n");
	return $rand_key;
	}
pick_rand($input);
foreach ($rand_key as $i){
	print ("Number $i : ");
	echo $input[$i] . "\n";
	}
#echo $input[pick_rand($input)] . "\n";
#echo $input[$rand_keys] . "\n";
#echo $input[$rand_keys] . "\n";
?>
