#!/var/lib/asterisk/agi-bin/pyst_env/bin/python
from asterisk.agi import *
#import asterisk.agi
import asterisk.manager
import sys
import random
import re
import MySQLdb

#====  DB CREDENTIALS  ===
db=MySQLdb.connect("localhost","vitel_user","vitel_pbx123","asterisk")
verbosity =  True
agi = AGI()
# Asterisk Manager Interface (AMI) credentials
ami_host = 'localhost'
#ami_host = '38.143.106.184'
ami_port = 5038
ami_username = 'viteluser'
ami_password = 'vitelpbx123'

tenant = agi.get_variable('CUST_ID')
rg_num = agi.get_variable('RINGGROUP_NUM')
# Execute the query to retrieve ringgroups data
#rg_query = f"SELECT * FROM ringgroups WHERE grp_exten='{rg_num}'"
rg_query = f"SELECT strategy, grplist, musiconhold, prompt_id, cid_name_prefix, grp_ringtime, enable_dest, postdest, postdest_value, skip_busy, ignore_cf, call_recording FROM ringgroups WHERE grp_exten='{rg_num}'"
agi.verbose(rg_query)
c=db.cursor()
c.execute(rg_query)
rg_res = c.fetchone()
#agi.verbose(rg_res)
res_ty = str(type(rg_res)).split("'")[1]
agi.verbose(res_ty)
#for x in rg_res:
#	agi.verbose(x)
if res_ty == "NoneType":
	agi.verbose("INVALID RG NUMBER")
	c.close()
	db.close()
	exit()
else:
	agi.verbose("Data Found")
	grp_strategy=rg_res[0]
	agi.verbose(f"strategy: {grp_strategy}")
	grp_list=rg_res[1]
	moh_class=rg_res[2]
	prompt_id=rg_res[3]
	cid_name_prefix=rg_res[4]
	grp_ringtime=rg_res[5]
	dest_check=rg_res[6]
	post_dest=rg_res[7]
	post_dest_value=rg_res[8]
	skip_wn_busy=rg_res[9]
	ignore_cf=rg_res[10]
	call_recording_option=rg_res[11]

#	CLOSING CURSOR CONNECTION
	c.close()

	agi.verbose("ASSIGNING VARIABLES")
	agi.set_variable("__FINAL_DEST_CHECK", dest_check)
	agi.set_variable("__CID_NAME_PREFIX",cid_name_prefix)
	agi.set_variable("__MOH_CLASS", moh_class)
	agi.set_variable("__SKIPBUSY_AGENT", skip_wn_busy)
	agi.set_variable("__RINGGROUP_ID", rg_num)
	agi.set_variable("__IGNORE_CF", ignore_cf)
	agi.set_variable("__REC_OPT", call_recording_option)
	agi.verbose("PRINTING  VARIABLE VALUES")
	agi.set_variable("__FINAL_DEST_CHECK", dest_check)
	agi.verbose(f"strategy: {grp_strategy} Grp List: {grp_list}  MOH CLASS: {moh_class}   Audio File: {prompt_id}  PREFIX: {cid_name_prefix}  RingTime: {grp_ringtime}  Dest Check: {dest_check}  Destination: {post_dest}  Destination Value: {post_dest_value}  SkipBusy: {skip_wn_busy}  IGNORE_CF: {ignore_cf}  Recording: {call_recording_option}")


grp_exten_list  = grp_list.split('-')
len_grp_list   = len(grp_exten_list)

agi.verbose(f"FINAL DESTINATION CHECK IS '{dest_check}'")
agi.verbose(f"EXT GRP LIST IS '{grp_list}'")
agi.verbose(f"CID(NAME) PREFIX FOR RING GROUP '{rg_num}' SET TO '{cid_name_prefix}'")
agi.verbose(f"ARRAY LENGTH IS '{len_grp_list}'")
agi.verbose(f"SKIP BUSY AGENT STATUS IS SET TO '{skip_wn_busy}'")
agi.verbose(f"RING GROUP STRATEGY IS '{grp_strategy}'")
agi.verbose(f"IGNORE CALL FORWARD STATUS IS SET TO {ignore_cf}")
agi.verbose(f"CALL RECORDING FOR RINGGROUP '{rg_num}' WAS SET TO '{call_recording_option}'")


#	  GETTING AUDIO PROMPT DETAILS - START
audioQuery = f"SELECT File_Location  FROM pss_audio_files where File_id='{prompt_id}'"
cursor = db.cursor()
cursor.execute(audioQuery)
audioData = cursor.fetchone()
agi.verbose(audioQuery)
result_type = str(type(audioData)).split("'")[1]
if result_type == 'NoneType':
	agi.verbose(db.error)
	#die("Error fetching patterns: {}".format(db.error))
	agi.set_variable("AUD_FILE_LOC", "INVALID")
	agi.verbose("PROMPT FILE LOCATION NOT FOUND")

else:
	# Get field information for all fields
	aud_file_loc	=	audioData[0]
#	CLOSING CURSOR CONNECTION
	cursor.close()
	if (verbosity):
		agi.verbose(f"AUDIO PROMPT IS {aud_file_loc}")
		agi.set_variable("AUD_FILE_LOC", aud_file_loc)
#	  GETTING AUDIO PROMPT DETAILS - END

agi.set_variable("__IGNORE_CF", ignore_cf)
agi.set_variable("__POST_DEST", post_dest)
agi.set_variable("__DEST_VALUE", post_dest_value)
agi.set_variable("__GRP_DIAL_STRING", grp_list)
agi.set_variable("__GRP_RING_TIME", grp_ringtime)
agi.verbose(f"-->GROUP STRATEGY IS {grp_strategy}")
agi.set_variable("__RG_STRATEGY", grp_strategy)
agi.verbose("testing =============")
if (len_grp_list == 0):
	agi.verbose("RING GROUP LIST IS EMPTY")
	db.close()
	exit()
agi.verbose("CHECKING GROUP STRATEGY")

if (grp_strategy == 'ringall'):
	if (verbosity):
		agi.verbose("RING GROUP STRATEGY IS 'RINGALL'")

elif (grp_strategy == 'hunt'):
	if (verbosity):
		agi.verbose("RING GROUP STRATEGY IS 'HUNT'")
		agi.verbose("=======RING GROUP STRATEGY IS 'HUNT'==========")
	agi.set_variable("__HUNT_COUNT", len_grp_list)
	agi.set_variable("__EXTEN_STRING", grp_list)
	myhuntmember=''
	for i in range(len_grp_list):
		myhuntmember = "HUNTMEMBER" + str(i)
		if (verbosity):
			agi.verbose(f"SETTING HUNT MEMEBER {myhuntmember} TO {grp_exten_list[i]}")
		#//extstate = is_ext_avail(AGI, grp_exten_list[i])
		agi.set_variable(myhuntmember, grp_exten_list[i])
	
elif (grp_strategy == 'random'):
	if (verbosity):
		agi.verbose("RING GROUP STRATEGY IS 'RANDOM'")

		# DIAL `ANY ONE` EXTEN RANDOMLY

#	agi.set_variable("__EXT_COUNT", len_grp_list)
#	agi.set_variable("__EXTEN_STRING", grp_list)
#	myExtMember=''
#	for i in range(len_grp_list):
#		myExtMember = "EXTMEMBER" + str(i)
#		if (verbosity):
#			agi.verbose(f"SETTING EXTEN {myExtMember} TO {grp_exten_list[i]}")
#		#//extstate = is_ext_avail(AGI, grp_exten_list[i])
#		agi.set_variable(myExtMember, grp_exten_list[i])
#

		# DIAL ALL LISTED EXTENSIONS IN RANDOM ORDER

	agi.set_variable("__HUNT_COUNT", len_grp_list)
	agi.set_variable("__EXTEN_STRING", grp_list)
	myExtMember=''

	#randomizing the list of extensiosn
	rand_extn_list = grp_exten_list.copy()
	agi.verbose(f"COPIED EXTEN LIST: {rand_extn_list}")
	random.shuffle(rand_extn_list)
	agi.verbose(f"RANDOM EXTEN LIST: {rand_extn_list}")
	for i in range(len_grp_list):
		myExtMember = "HUNTMEMBER" + str(i)
		if (verbosity):
			agi.verbose(f"SETTING EXTEN {myExtMember} TO {rand_extn_list[i]}")
		agi.set_variable(myExtMember, rand_extn_list[i])


elif (grp_strategy == 'fnop'):
	if (verbosity):
		agi.verbose("RING GROUP STRATEGY IS 'FIRST NOT ON PHONE'")
	for i in range(len_grp_list):
		exten_num = grp_exten_list[i]
		if (verbosity):
			agi.verbose(f"CHECKING STATUS OF EXTEN {exten_num}")
 
		extn_status_qry = f"select status from exten_live_status where extension='{exten_num}'"
	#	agi.verbose(extn_status_qry)
		c=db.cursor()
		c.execute(extn_status_qry)
		extn_status_res = c.fetchone()
	#	agi.verbose(f"RESULT IS {extn_status_res}")
		extn_res_ty = str(type(extn_status_res)).split("'")[1]
	#	agi.verbose(extn_res_ty)
	#	for x in extn_status_res:
	#	 	agi.verbose(x)
		#exit()
		if extn_res_ty == "NoneType":
			agi.verbose("EXTENSION STATUS DATA 'NOT FOUND'")
			c.close()
		else:
			#agi.verbose("EXTENSION STATUS DATA 'FOUND'")
			extn_status = extn_status_res[0]
			agi.verbose(f"{exten_num} => {extn_status}")
			if extn_status == 'NOT_INUSE':
			#	agi.verbose(f"FOUND AVAILABLE EXTENSION {exten_num}")
				agi.set_variable("__RAND_EXTEN", exten_num)
				c.close()
				db.close()
				exit()
			#		 CLOSING CURSOR CONNECTION
		c.close()


elif (grp_strategy == 'favail'):
	if (verbosity):
		agi.verbose("RING GROUP STRATEGY IS 'FIRST AVAILABLE'")
	for i in range(len_grp_list):
		exten_num = grp_exten_list[i]
		if (verbosity):
			agi.verbose(f"CHECKING STATUS OF EXTEN {exten_num}")

		extn_status_qry = f"select status from exten_live_status where extension='{exten_num}'"
		c=db.cursor()
		c.execute(extn_status_qry)
		extn_status_res = c.fetchone()
		extn_res_ty = str(type(extn_status_res)).split("'")[1]
		if extn_res_ty == "NoneType":
			agi.verbose("EXTENSION STATUS DATA 'NOT FOUND'")
			c.close()
		else:
			#agi.verbose("EXTENSION STATUS DATA 'FOUND'")
			extn_status = extn_status_res[0]
			agi.verbose(f"{exten_num} => {extn_status}")
			if extn_status in ['UNAVAILABLE', 'INVALID', 'UNKNOWN']:
				agi.verbose(f"FOUND UNAVAILABLE EXTENSION {exten_num}")
				continue
			else:
				agi.verbose(f"FOUND AVAILABLE EXTENSION {exten_num}")
				agi.set_variable("__RAND_EXTEN", exten_num)
				c.close()
				db.close()
				exit()
		#      CLOSING CURSOR CONNECTION
		c.close()
else:
	agi.verbose("INVALID RINGING STRATEGY")
db.close()
agi.verbose("NOW LEAVING 'RG-DIAL' AGI FILE")
