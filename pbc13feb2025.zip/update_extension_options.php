#!/usr/bin/env /bin/php

<?php
require('phpagi.php');
//require('include/phpagi.php');
error_reporting(E_ALL);

//$db_ip = "127.0.0.1";
$db_ip = "localhost";
$db_user = "vitel_user";
$db_port = "3306";
$db_pass = "vitel_pbx123";

// Create MySQL connection
$mysqli = new mysqli($db_ip, $db_user, $db_pass, "asterisk");
if ($mysqli->connect_errno) {
    fwrite($stderr, "Failed to connect to MySQL: " . $mysqli->connect_error . "\n");
    exit(1);
}
# create new Agi
$AGI = new AGI();

if (!$AGI) {
        // something went wrong
$AGI->verbose("something went wrong");
        exit(1);
}
$AGI->verbose("MySQL connection Up");
$AGI->verbose("script starting up");

    // set parameters
	$Tenant 	= 	$argv[1];
	$Exten  	= 	$argv[2];
	$update_param 	= 	strtolower($argv[3]);
	$update_status 	= 	strtolower($argv[4]);
	$addl_info	=	$argv[5];
	$AGI->verbose("PARAMETER TO UPDATE $update_param");
	$AGI->verbose(" UPDATED TO STATUS $update_status");


//$AGI->verbose("call for \"$Tenant$Exten\"");
$AGI->verbose("call for \"$Exten\"");

//  Check Call Forward Status and Fetch Forward Number data from a MySQL table

 $query1 = "update extension_options set $update_param='$update_status' where exten='$Exten'";
 $AGI->verbose($query1);
 if($result1 = $mysqli->prepare($query1)) {

        $AGI->verbose("exten_option UPDATING STATUS");
           if($mysqli->query($query1)) {
                echo "exten_option Column value updated successfully.";
             }
	    else{
                  echo "Error exten_option updating column value: " . $result1->error;
	     }
 }

 else{
    	 $AGI->verbose("Error in exten_option preparing statement: " . $conn->error);
   }
				
$result1->close();

$query2 = "update followme set enable_followme='$update_status' where name='$Exten'";
$AGI->verbose($query2);
if($result2 = $mysqli->prepare($query2)) {
    $AGI->verbose("followme UPDATING STATUS followme");
        if ($mysqli->query($query2)) {
            echo " followme Column value updated successfully.";
	} 
	else {
                echo "Error followme updating column value: " . $result2->error;
         }
                                                }
else{
      $AGI->verbose("Error in followme preparing statement: " . $conn->error);
    }
$result2->close();

$query1 = "SELECT $update_param FROM extension_options where exten='$Exten'"; 
if ($result1 = $mysqli -> query($query1)) {
  // Get field information for all fields
    while ($fieldinfo = $result1 -> fetch_assoc()) {
    //$AGI->verbose($result);
	$current_status=$fieldinfo["$update_param"];
 
	$AGI->verbose("$update_param of $Exten is $current_status");
  }
	$result1->free_result();
	//$result1->close();
}

if ($update_param == 'call_fwd_all' and $update_status == 'yes'){
        $query2 = "update extension_options set callfwd_all_num='$addl_info' where  exten='$Exten'";#cust_id='$Tenant' 
        $AGI->verbose($query2);
        if ($result2 = $mysqli->prepare($query2)) {
   // $AGI->verbose($result2);
        $AGI->verbose("UPDATING STATUS");
        if ($mysqli->query($query2)) {
                echo "Column value updated successfully.";
        } else {
                echo "Error updating column value: " . $result->error;
                }
                                                }
        else{
                $AGI->verbose("Error in preparing statement: " . $mysqli->error);
                }
        $result2->close();
	//$mysqli->close();

}elseif($update_param == 'call_fwd_na' and $update_status == 'yes'){
        $query2 = "update extension_options set callfwd_na_num='$addl_info' where exten='$Exten'";# and cust_id='$Tenant'
        $AGI->verbose($query2);
        if ($result2 = $mysqli->prepare($query2)) {
   // $AGI->verbose($result2);
        $AGI->verbose("UPDATING STATUS");
        if ($mysqli->query($query2)) {
                echo "Column value updated successfully.";
        } else {
                echo "Error updating column value: " . $result->error;
                }
                                                }
        else{
                $AGI->verbose("Error in preparing statement: " . $mysqli->error);
                }
        $result2->close();
        //$mysqli->close();



}elseif($update_param == 'call_fwd_busy' and $update_status == 'yes'){
        $query2 = "update extension_options set callfwd_busy_num='$addl_info' where exten='$Exten'";# and cust_id='$Tenant'
        $AGI->verbose($query2);
        if ($result2 = $mysqli->prepare($query2)) {
   // $AGI->verbose($result2);
        $AGI->verbose("UPDATING STATUS");
        if ($mysqli->query($query2)) {
                echo "Column value updated successfully.";
        } else {
                echo "Error updating column value: " . $result->error;
                }
                                                }
        else{
                $AGI->verbose("Error in preparing statement: " . $mysqli->error);
                }
        $result2->close();
        $mysqli->close();


}else{
	$AGI->verbose('NOT A CALL FORWARD REQUEST');
	$mysqli->close();    
	}
    # set return variable
    $AGI->set_variable(XXXXXXXXXXXXX, $DND_status);

?>
