#!/usr/bin/env /bin/php
<?php
$socket = fsockopen('localhost', 5038, $errno, $errstr, 30);
if (!$socket) {
    echo "Error: $errstr ($errno)\n";
} else {
    // Connection successful
 echo "success\n\n\n"; 

$login = "Action: Login\r\nUsername: viteluser\r\nSecret: vitelpbx123\r\n\r\n";
fwrite($socket, $login);

$command = "Action: MailboxCount\r\nActionID: 123\r\nMailbox: 101\r\n\r\n";
fwrite($socket, $command);

$response = '';
while (!feof($socket)) {
    $response .= fgets($socket, 4096);
}
fclose($socket);

// Process the response to extract call data
// For example, you can split the response by newline to get individual lines
$lines = explode("\r\n", $response);

foreach ($lines as $line) {
    // Process each line to extract call data
    echo $line;
}
}
?>
