#!/usr/bin/env /bin/php
<?php
require('phpagi.php');
require('modules.php');
require_once("mysql_connect.php");
$script = 'voicemail_check.php';
$verbosity = True;
error_reporting(E_ALL);
// Create MySQL connection
$mysqli = connectToDatabase();

# create new Agi
$AGI = new AGI();
if (!$AGI) {
$AGI->verbose("something went wrong");
        exit(1);}
$AGI->verbose("$script starting up");
    
if ($mysqli->connect_errno) {
    fwrite($stderr, "Failed to connect to MySQL: " . $mysqli->connect_error . "\n");
    exit(1);}
$AGI->verbose("MySQL connection Up");
// set parameters
$caller = $argv[1];
$query = "SELECT voicemail_status FROM extension_options where exten=$caller";
    $AGI->verbose($query);
$result = $mysqli->query($query);

if($result){
	$row = $result->fetch_assoc();
	if($row){
		$voicemail_status = $row['voicemail_status'];
                $AGI->verbose("vm status $voicemail_status");
		if($voicemail_status === 'no'){ 
		       $AGI->Verbose("VM is not enabled for $caller");	
		       $AGI->Hangup();
		       exit(0);
		}
	}
	else
	{
		$AGI->verbose("Query failed: " . $mysqli->error);
		$AGI->exec('hangup');
		exit(1);
		//$voicemail_status="none";
	}

}
$result -> free_result();
$mysqli -> close();    
    # set return variable
   	$AGI->set_variable("VM_STATUS", $voicemail_status);
     //   $AGI->exec('Gosub', 'page-dial,s,1');
  

?>
